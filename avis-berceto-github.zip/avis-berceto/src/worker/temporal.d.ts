declare namespace Temporal {
  class Instant {
    static fromEpochMilliseconds(epochMilliseconds: number): Instant;
    toZonedDateTimeISO(timeZone: string): ZonedDateTime;
  }

  class ZonedDateTime {
    static from(
      item: {
        timeZone: string;
        year: number;
        month: number;
        day: number;
        hour: number;
        minute: number;
      },
      options?: { disambiguation?: 'compatible' | 'earlier' | 'later' | 'reject' },
    ): ZonedDateTime;
    toPlainDate(): PlainDate;
    epochMilliseconds: number;
  }

  class PlainDate {
    static from(item: string | { year: number; month: number; day: number }): PlainDate;
    static compare(one: PlainDate, other: PlainDate): number;
    year: number;
    month: number;
    day: number;
    dayOfWeek: number;
    daysInMonth: number;
    add(duration: { years?: number; months?: number; days?: number }): PlainDate;
    subtract(duration: { days?: number }): PlainDate;
    with(fields: { day?: number }): PlainDate;
    until(
      other: PlainDate,
      options?: { largestUnit?: 'year' | 'month' | 'week' | 'day' },
    ): { years: number; months: number; weeks: number; days: number };
    toString(): string;
  }
}
