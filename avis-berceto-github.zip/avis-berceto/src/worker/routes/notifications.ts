import type { Hono } from 'hono';
import { pushSubscriptionSchema } from '../../shared/schemas';
import { jsonBody, requireUuid } from '../http';
import {
  deletePushSubscription,
  listNotifications,
  markAllNotificationsRead,
  markNotificationRead,
  savePushSubscription,
  vapidPublicKey,
} from '../notifications';
import type { AppEnv } from '../types';

export function mountNotifications(app: Hono<AppEnv>): void {
  app.get('/api/notifications', async (c) => c.json(await listNotifications(c)));
  app.post('/api/notifications/read-all', async (c) => c.json(await markAllNotificationsRead(c)));
  app.post('/api/notifications/:id/read', async (c) =>
    c.json(await markNotificationRead(c, requireUuid(c.req.param('id')))),
  );
  app.get('/api/push/vapid-public-key', async (c) => c.json(await vapidPublicKey(c)));
  app.post('/api/push/subscriptions', jsonBody(pushSubscriptionSchema), async (c) =>
    c.json(await savePushSubscription(c, c.req.valid('json')), 201),
  );
  app.delete('/api/push/subscriptions/:id', async (c) =>
    c.json(await deletePushSubscription(c, requireUuid(c.req.param('id')))),
  );
}
