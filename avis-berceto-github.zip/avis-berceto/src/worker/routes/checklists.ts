import type { Hono } from 'hono';
import {
  checklistListQuerySchema,
  createChecklistSchema,
  patchChecklistItemSchema,
  patchChecklistSchema,
  startChecklistRunSchema,
} from '../../shared/schemas';
import {
  cancelRun,
  completeRun,
  createTemplate,
  getRun,
  getTemplate,
  listRuns,
  listTemplates,
  startRun,
  updateRunItem,
  updateTemplate,
} from '../checklists';
import { jsonBody, queryOf, requireUuid } from '../http';
import type { AppEnv } from '../types';

export function mountChecklists(app: Hono<AppEnv>): void {
  app.get('/api/checklist-templates', queryOf(checklistListQuerySchema), async (c) =>
    c.json(await listTemplates(c, c.req.valid('query'))),
  );
  app.post('/api/checklist-templates', jsonBody(createChecklistSchema), async (c) =>
    c.json(await createTemplate(c, c.req.valid('json')), 201),
  );
  app.get('/api/checklist-templates/:id', async (c) =>
    c.json(await getTemplate(c, requireUuid(c.req.param('id')))),
  );
  app.patch('/api/checklist-templates/:id', jsonBody(patchChecklistSchema), async (c) =>
    c.json(await updateTemplate(c, requireUuid(c.req.param('id')), c.req.valid('json'))),
  );
  app.post('/api/checklist-templates/:id/runs', jsonBody(startChecklistRunSchema), async (c) =>
    c.json(await startRun(c, requireUuid(c.req.param('id')), c.req.valid('json')), 201),
  );
  app.get('/api/checklist-runs', async (c) => c.json(await listRuns(c)));
  app.get('/api/checklist-runs/:id', async (c) =>
    c.json(await getRun(c, requireUuid(c.req.param('id')))),
  );
  app.patch(
    '/api/checklist-runs/:id/items/:itemId',
    jsonBody(patchChecklistItemSchema),
    async (c) =>
      c.json(
        await updateRunItem(
          c,
          requireUuid(c.req.param('id')),
          requireUuid(c.req.param('itemId')),
          c.req.valid('json'),
        ),
      ),
  );
  app.post('/api/checklist-runs/:id/complete', async (c) =>
    c.json(await completeRun(c, requireUuid(c.req.param('id')))),
  );
  app.post('/api/checklist-runs/:id/cancel', async (c) =>
    c.json(await cancelRun(c, requireUuid(c.req.param('id')))),
  );
}
