import type { Hono } from 'hono';
import {
  acceptInvite,
  changePassword,
  confirmReset,
  login,
  logout,
  setupAccount,
  setupStatus,
  updateOwnName,
} from '../auth-service';
import { assertCsrf, jsonBody } from '../http';
import { requireUser } from '../session';
import {
  acceptSchema,
  changePasswordSchema,
  loginSchema,
  patchMeSchema,
  setupSchema,
} from '../../shared/schemas';
import type { AppEnv } from '../types';

export function mountAuth(app: Hono<AppEnv>): void {
  app.use('/api/*', async (c, next) => {
    assertCsrf(c);
    await next();
  });

  app.get('/api/setup', async (c) => c.json(await setupStatus(c)));
  app.post('/api/setup', jsonBody(setupSchema), async (c) =>
    c.json(await setupAccount(c, c.req.valid('json')), 201),
  );
  app.post('/api/auth/login', jsonBody(loginSchema), async (c) =>
    c.json(await login(c, c.req.valid('json'))),
  );
  app.post('/api/auth/logout', async (c) => {
    await logout(c);
    return c.json({ ok: true });
  });
  app.get('/api/auth/me', async (c) => {
    const user = await requireUser(c);
    const row = await c.env.DB.prepare(
      `SELECT value FROM app_settings WHERE key = 'association_name'`,
    ).first<{ value: string }>();
    return c.json({
      id: user.id,
      fullName: user.fullName,
      email: user.email,
      role: user.role,
      status: user.status,
      groups: user.groups,
      associationName: row?.value || 'Avis Berceto',
    });
  });
  app.patch('/api/me', jsonBody(patchMeSchema), async (c) =>
    c.json(await updateOwnName(c, c.req.valid('json'))),
  );
  app.post('/api/me/password', jsonBody(changePasswordSchema), async (c) =>
    c.json(await changePassword(c, c.req.valid('json'))),
  );
  app.post('/api/auth/invitations/accept', jsonBody(acceptSchema), async (c) =>
    c.json(await acceptInvite(c, c.req.valid('json'))),
  );
  app.post('/api/auth/password-reset/confirm', jsonBody(acceptSchema), async (c) =>
    c.json(await confirmReset(c, c.req.valid('json'))),
  );
}
