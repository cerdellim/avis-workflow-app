import type { Hono } from 'hono';
import { createTaskSchema, patchTaskSchema, taskListQuerySchema } from '../../shared/schemas';
import { loadDashboard } from '../dashboard';
import { jsonBody, queryOf, requireUuid } from '../http';
import {
  cancelTask,
  claimTask,
  completeTask,
  createTask,
  getTask,
  listTasks,
  releaseTask,
  reopenTask,
  taskHistory,
  updateTask,
} from '../tasks';
import type { AppEnv } from '../types';

export function mountTasks(app: Hono<AppEnv>): void {
  app.get('/api/dashboard', async (c) => c.json(await loadDashboard(c)));
  app.get('/api/tasks', queryOf(taskListQuerySchema), async (c) =>
    c.json(await listTasks(c, c.req.valid('query'))),
  );
  app.post('/api/tasks', jsonBody(createTaskSchema), async (c) =>
    c.json(await createTask(c, c.req.valid('json')), 201),
  );
  app.get('/api/tasks/:id/history', async (c) =>
    c.json(await taskHistory(c, requireUuid(c.req.param('id')))),
  );
  app.get('/api/tasks/:id', async (c) => c.json(await getTask(c, requireUuid(c.req.param('id')))));
  app.patch('/api/tasks/:id', jsonBody(patchTaskSchema), async (c) =>
    c.json(await updateTask(c, requireUuid(c.req.param('id')), c.req.valid('json'))),
  );
  app.post('/api/tasks/:id/claim', async (c) =>
    c.json(await claimTask(c, requireUuid(c.req.param('id')))),
  );
  app.post('/api/tasks/:id/release', async (c) =>
    c.json(await releaseTask(c, requireUuid(c.req.param('id')))),
  );
  app.post('/api/tasks/:id/complete', async (c) =>
    c.json(await completeTask(c, requireUuid(c.req.param('id')))),
  );
  app.post('/api/tasks/:id/reopen', async (c) =>
    c.json(await reopenTask(c, requireUuid(c.req.param('id')))),
  );
  app.post('/api/tasks/:id/cancel', async (c) =>
    c.json(await cancelTask(c, requireUuid(c.req.param('id')))),
  );
}
