import type { Hono } from 'hono';
import { auditQuerySchema, patchSettingsSchema } from '../../shared/schemas';
import {
  exportBackup,
  exportTasksCsv,
  listAuditLogs,
  readSettings,
  updateSettings,
} from '../admin';
import { jsonBody, queryOf } from '../http';
import type { AppEnv } from '../types';

export function mountAdmin(app: Hono<AppEnv>): void {
  app.get('/api/audit-logs', queryOf(auditQuerySchema), async (c) =>
    c.json({ items: await listAuditLogs(c, c.req.valid('query')) }),
  );
  app.get('/api/settings', async (c) => c.json(await readSettings(c)));
  app.patch('/api/settings', jsonBody(patchSettingsSchema), async (c) =>
    c.json(await updateSettings(c, c.req.valid('json'))),
  );
  app.get('/api/exports/tasks.csv', async (c) => {
    const csv = await exportTasksCsv(c);
    c.header('Content-Type', 'text/csv; charset=utf-8');
    c.header('Content-Disposition', 'attachment; filename="attivita.csv"');
    return c.body(csv);
  });
  app.get('/api/exports/backup', async (c) => {
    c.header('Content-Disposition', 'attachment; filename="volontari-backup.json"');
    return c.json(await exportBackup(c));
  });
}
