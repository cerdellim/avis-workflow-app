import type { Hono } from 'hono';
import {
  calendarQuerySchema,
  createRecurrenceSchema,
  patchRecurrenceSchema,
  suspendRecurrenceSchema,
} from '../../shared/schemas';
import { jsonBody, queryOf, requireUuid } from '../http';
import {
  createRecurrence,
  getRecurrence,
  listRecurrences,
  loadCalendar,
  resumeRecurrence,
  suspendRecurrence,
  updateRecurrence,
} from '../recurrences';
import { requireAdmin, requireUser } from '../session';
import { runTick, vapidOptions } from '../tick';
import type { AppEnv } from '../types';

export function mountRecurrences(app: Hono<AppEnv>): void {
  app.get('/api/recurrences', async (c) => c.json(await listRecurrences(c)));
  app.post('/api/recurrences', jsonBody(createRecurrenceSchema), async (c) =>
    c.json(await createRecurrence(c, c.req.valid('json')), 201),
  );
  app.get('/api/recurrences/:id', async (c) =>
    c.json(await getRecurrence(c, requireUuid(c.req.param('id')))),
  );
  app.patch('/api/recurrences/:id', jsonBody(patchRecurrenceSchema), async (c) =>
    c.json(await updateRecurrence(c, requireUuid(c.req.param('id')), c.req.valid('json'))),
  );
  app.post('/api/recurrences/:id/suspend', jsonBody(suspendRecurrenceSchema), async (c) =>
    c.json(await suspendRecurrence(c, requireUuid(c.req.param('id')), c.req.valid('json'))),
  );
  app.post('/api/recurrences/:id/resume', async (c) =>
    c.json(await resumeRecurrence(c, requireUuid(c.req.param('id')))),
  );
  app.get('/api/calendar', queryOf(calendarQuerySchema), async (c) =>
    c.json(await loadCalendar(c, c.req.valid('query'))),
  );
  app.post('/api/admin/jobs/tick', async (c) => {
    const user = await requireUser(c);
    requireAdmin(user);
    return c.json(await runTick(c.env.DB, Date.now(), user.id, vapidOptions(c.env)));
  });
}
