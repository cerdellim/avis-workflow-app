import { describe, expect, it } from 'vitest';
import { ApiError, errorBody } from '../../src/shared/errors';
import { buildHealthBody } from '../../src/shared/health';

describe('stato del servizio', () => {
  it('segnala il database pronto', () => {
    const body = buildHealthBody(true, new Date('2026-11-18T12:00:00.000Z'));
    expect(body).toEqual({
      status: 'ok',
      service: 'volontari',
      database: 'ok',
      time: '2026-11-18T12:00:00.000Z',
    });
  });

  it('segnala il database non disponibile', () => {
    const body = buildHealthBody(false, new Date('2026-11-18T12:00:00.000Z'));
    expect(body.status).toBe('degraded');
    expect(body.database).toBe('error');
  });
});

describe('errori API', () => {
  it('restituisce il messaggio di un errore previsto', () => {
    const mapped = errorBody(new ApiError(403, 'forbidden', 'Operazione non consentita.'));
    expect(mapped.status).toBe(403);
    expect(mapped.body.error.code).toBe('forbidden');
  });

  it('nasconde i dettagli di un errore imprevisto', () => {
    const mapped = errorBody(new Error('sql exploded'));
    expect(mapped).toEqual({
      status: 500,
      body: {
        error: {
          code: 'internal_error',
          message: 'Si è verificato un errore. Riprova.',
        },
      },
    });
  });
});
