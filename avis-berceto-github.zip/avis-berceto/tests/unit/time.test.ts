import { describe, expect, it } from 'vitest';
import { isoToRomeInput, romeInputToIso } from '../../src/web/time';

describe('orario di Roma', () => {
  it('converte l’inverno e l’estate senza spostare il giorno', () => {
    expect(romeInputToIso('2026-01-15T18:00')).toBe('2026-01-15T17:00:00.000Z');
    expect(romeInputToIso('2026-07-15T18:00')).toBe('2026-07-15T16:00:00.000Z');
    expect(isoToRomeInput('2026-01-15T17:00:00.000Z')).toBe('2026-01-15T18:00');
    expect(isoToRomeInput('2026-07-15T16:00:00.000Z')).toBe('2026-07-15T18:00');
  });
});
