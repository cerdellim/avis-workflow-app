import { describe, expect, it } from 'vitest';
import { passwordProblem } from '../../src/shared/password-policy';
import { passwordSchema } from '../../src/shared/schemas';
import { equalDigests, tokensMatch } from '../../src/worker/crypto';
import { PASSWORD_ITERATIONS, hashPassword, verifyPassword } from '../../src/worker/passwords';

const PHRASE = 'una frase lunga ok';

describe('password', () => {
  it('tiene fisse 10.000 iterazioni e rifiuta una password di 15 caratteri', async () => {
    expect(PASSWORD_ITERATIONS).toBe(10_000);
    expect(passwordProblem('123456789012345')).toBe('Usa una frase di almeno 16 caratteri.');
    expect(passwordSchema.safeParse('123456789012345').success).toBe(false);
    expect(passwordProblem(PHRASE)).toBeNull();
    expect(passwordSchema.safeParse(PHRASE).success).toBe(true);
    expect(passwordProblem('passwordpassword')).toBe(
      "Questa frase è troppo comune. Scegline un'altra.",
    );

    const stored = await hashPassword(PHRASE);
    expect(stored.startsWith('pbkdf2-sha256$10000$')).toBe(true);
    expect(await verifyPassword(PHRASE, stored)).toBe(true);
    expect(await verifyPassword('una frase diversa', stored)).toBe(false);
    expect(await verifyPassword(PHRASE, null)).toBe(false);
  });

  it('confronta i digest e non la lunghezza originale del token', async () => {
    expect(await tokensMatch('segreto', 'segreto')).toBe(true);
    await expect(tokensMatch('a', 'bbbbbbbbbbbbbbbbbbbbbbbb')).resolves.toBe(false);
    expect(() => equalDigests(new Uint8Array([1]), new Uint8Array([1, 2]))).toThrow(
      /digest_length/,
    );
  });
});
