import { describe, expect, it } from 'vitest';
import { contrastRatio } from '../../src/shared/contrast';
import { csvCell, toCsv } from '../../src/shared/csv';

describe('csv e contrasto', () => {
  it('neutralizza le celle che un foglio di calcolo interpreterebbe come formule', () => {
    expect(csvCell('=SOMMA(1;1)')).toBe("'=SOMMA(1;1)");
    expect(csvCell('+39')).toBe("'+39");
    expect(csvCell('-1')).toBe("'-1");
    expect(csvCell('@cmd')).toBe("'@cmd");
    expect(csvCell('sala')).toBe('sala');
    expect(csvCell('a,b')).toBe('"a,b"');
    expect(csvCell('=a,b')).toBe(`"'=a,b"`);
    expect(toCsv([['Titolo'], ['=1']]).charCodeAt(0)).toBe(0xfeff);
  });

  it('mantiene il contrasto del testo sopra 4.5', () => {
    expect(contrastRatio('#17211e', '#f3f5f4')).toBeGreaterThanOrEqual(4.5);
    expect(contrastRatio('#17211e', '#ffffff')).toBeGreaterThanOrEqual(4.5);
    expect(contrastRatio('#3e4c48', '#f3f5f4')).toBeGreaterThanOrEqual(4.5);
    expect(contrastRatio('#3e4c48', '#ffffff')).toBeGreaterThanOrEqual(4.5);
    expect(contrastRatio('#ffffff', '#005eb8')).toBeGreaterThanOrEqual(4.5);
    expect(contrastRatio('#ffffff', '#004482')).toBeGreaterThanOrEqual(4.5);
  });
});
