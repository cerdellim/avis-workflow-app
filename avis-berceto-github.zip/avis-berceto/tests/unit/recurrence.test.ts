import { describe, expect, it } from 'vitest';
import {
  dueAtMillis,
  occurrenceDates,
  type RecurrenceSpec,
} from '../../src/worker/recurrence-dates';

const daily: RecurrenceSpec = {
  frequency: 'daily',
  intervalCount: 1,
  weekdays: null,
  dayOfMonth: null,
  monthOfYear: null,
  startsOn: '2026-12-01',
  endsOn: '2027-01-29',
};

describe('date delle ricorrenze', () => {
  it('converte il buco di marzo e l’ora doppia di ottobre', () => {
    expect(new Date(dueAtMillis('2026-03-29', '02:30')).toISOString()).toBe(
      '2026-03-29T01:30:00.000Z',
    );
    expect(new Date(dueAtMillis('2026-10-25', '02:30')).toISOString()).toBe(
      '2026-10-25T00:30:00.000Z',
    );
  });

  it('genera 60 date giornaliere e non un anno intero', () => {
    const dates = occurrenceDates(daily, '2026-12-01');
    expect(dates).toHaveLength(60);
    expect(dates[0]).toBe('2026-12-01');
    expect(dates.at(-1)).toBe('2027-01-29');
    const open = occurrenceDates({ ...daily, endsOn: null }, '2026-12-01');
    expect(open).toHaveLength(62);
    expect(open.at(-1)).toBe('2027-01-31');
  });

  it('tiene solo lunedì e giovedì', () => {
    const expected: string[] = [];
    let cursor = Temporal.PlainDate.from('2026-12-01');
    const end = Temporal.PlainDate.from('2026-12-31');
    while (Temporal.PlainDate.compare(cursor, end) <= 0) {
      if (cursor.dayOfWeek === 1 || cursor.dayOfWeek === 4) {
        expected.push(cursor.toString());
      }
      cursor = cursor.add({ days: 1 });
    }
    expect(
      occurrenceDates(
        {
          frequency: 'weekly',
          intervalCount: 1,
          weekdays: [1, 4],
          dayOfMonth: null,
          monthOfYear: null,
          startsOn: '2026-12-01',
          endsOn: '2026-12-31',
        },
        '2026-12-01',
      ),
    ).toEqual(expected);
  });

  it('accorcia il 31 senza spostare l’ancora', () => {
    const spec: RecurrenceSpec = {
      frequency: 'monthly',
      intervalCount: 1,
      weekdays: null,
      dayOfMonth: 31,
      monthOfYear: null,
      startsOn: '2027-01-01',
      endsOn: null,
    };
    expect(occurrenceDates(spec, '2027-01-01')).toEqual(['2027-01-31', '2027-02-28']);
    expect(occurrenceDates(spec, '2027-02-01')).toEqual(['2027-02-28', '2027-03-31']);
  });

  it('sposta il 29 febbraio solo negli anni comuni', () => {
    const spec: RecurrenceSpec = {
      frequency: 'yearly',
      intervalCount: 1,
      weekdays: null,
      dayOfMonth: 29,
      monthOfYear: 2,
      startsOn: '2027-01-01',
      endsOn: null,
    };
    expect(occurrenceDates(spec, '2027-01-15')).toEqual(['2027-02-28']);
    expect(occurrenceDates(spec, '2028-01-15')).toEqual(['2028-02-29']);
  });
});
