import swSource from '../../public/sw.js?raw';
import { describe, expect, it } from 'vitest';
import { notificationPath, openNotificationPath } from '../../src/shared/notification-click';

describe('click della notifica', () => {
  it('apre il percorso della task', async () => {
    const opened: string[] = [];
    await openNotificationPath(
      {
        matchAll: async () => [],
        openWindow: async (path) => {
          opened.push(path);
        },
      },
      notificationPath({ title: 'Nuova attività', path: '/attivita/task-1' }),
    );
    expect(opened).toEqual(['/attivita/task-1']);
  });

  it('porta in primo piano una finestra già su quel percorso', async () => {
    const focused: string[] = [];
    const opened: string[] = [];
    await openNotificationPath(
      {
        matchAll: async () => [
          {
            url: 'https://volontari.test/attivita/task-1',
            focus: async () => {
              focused.push('/attivita/task-1');
            },
          },
        ],
        openWindow: async (path) => {
          opened.push(path);
        },
      },
      '/attivita/task-1',
    );
    expect(focused).toEqual(['/attivita/task-1']);
    expect(opened).toEqual([]);
  });

  it('rifiuta un percorso esterno', () => {
    expect(notificationPath({ path: 'https://example.test/attivita/1' })).toBe('/notifiche');
    expect(notificationPath({ path: '//example.test/attivita/1' })).toBe('/notifiche');
    expect(notificationPath({ title: 'Solo il titolo' })).toBe('/notifiche');
  });

  it('nel service worker apre la finestra e non mette in cache le API', () => {
    expect(swSource).toContain('notificationclick');
    expect(swSource).toContain('openWindow(path)');
    expect(swSource).not.toContain('caches');
  });
});
