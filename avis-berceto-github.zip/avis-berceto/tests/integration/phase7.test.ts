import { env, exports } from 'cloudflare:workers';
import { describe, expect, it } from 'vitest';
import {
  BACKUP_TABLES,
  backupStatements,
  type BackupDocument,
} from '../../src/shared/backup-format';

const ORIGIN = 'http://volontari.test';
const BOOTSTRAP = 'token-di-collaudo-fase-2';
const PASSWORD = 'frase-di-prova-lunga';

let adminCookie = '';
let coordinatorCookie = '';
let volunteerCookie = '';
let outsiderCookie = '';
let groupId = '';
let otherGroupId = '';
let volunteerId = '';
let taskId = '';
let templateId = '';
let runId = '';
let ruleId = '';
let noticeId = '';

describe('amministrazione e sicurezza', () => {
  it('prepara due gruppi e le persone', async () => {
    const setup = await call('/api/setup', {
      method: 'POST',
      body: {
        bootstrapToken: BOOTSTRAP,
        fullName: 'Ada Admin',
        email: 'admin-fase7@example.org',
        password: PASSWORD,
      },
    });
    adminCookie = cookieOf(setup);
    groupId = idOf(
      await jsonOf(
        await call('/api/groups', {
          method: 'POST',
          cookie: adminCookie,
          body: { name: 'Squadra Alfa', description: '' },
        }),
      ),
    );
    otherGroupId = idOf(
      await jsonOf(
        await call('/api/groups', {
          method: 'POST',
          cookie: adminCookie,
          body: { name: 'Squadra Beta', description: '' },
        }),
      ),
    );
    const coordinator = await person('Ciro Coord', 'ciro-fase7@example.org', 'coordinator', [
      groupId,
    ]);
    const volunteer = await person('Vera Volontaria', 'vera-fase7@example.org', 'volunteer', [
      groupId,
    ]);
    const outsider = await person('Nino Esterno', 'nino-fase7@example.org', 'volunteer', [
      otherGroupId,
    ]);
    coordinatorCookie = coordinator.cookie;
    volunteerCookie = volunteer.cookie;
    outsiderCookie = outsider.cookie;
    volunteerId = volunteer.id;
  });

  it('nega le risorse di un altro gruppo e le notifiche altrui', async () => {
    taskId = idOf(
      await jsonOf(
        await call('/api/tasks', {
          method: 'POST',
          cookie: coordinatorCookie,
          body: taskBody('=SOMMA(1;1)', [volunteerId]),
        }),
      ),
    );
    const foreignTask = await jsonOf(
      await call('/api/tasks', {
        method: 'POST',
        cookie: adminCookie,
        body: {
          ...taskBody('Attività estranea', []),
          groupId: otherGroupId,
        },
      }),
    );
    const template = await jsonOf(
      await call('/api/checklist-templates', {
        method: 'POST',
        cookie: coordinatorCookie,
        body: {
          title: 'Controllo fase 7',
          description: '',
          groupId,
          items: [{ label: 'Estintore', helpText: '', required: true }],
        },
      }),
    );
    templateId = idOf(template);
    const run = await jsonOf(
      await call(`/api/checklist-templates/${templateId}/runs`, {
        method: 'POST',
        cookie: coordinatorCookie,
        body: {},
      }),
    );
    runId = idOf(run);
    const rule = await jsonOf(
      await call('/api/recurrences', {
        method: 'POST',
        cookie: coordinatorCookie,
        body: {
          title: 'Turno fase 7',
          description: '',
          groupId,
          assigneeIds: [],
          priority: 'normal',
          intervalCount: 1,
          localTime: '09:00',
          frequency: 'daily',
          startsOn: '2026-12-01',
        },
      }),
    );
    ruleId = idOf(rule);

    expect((await call(`/api/tasks/${taskId}`, { cookie: outsiderCookie })).status).toBe(404);
    expect(
      (await call(`/api/tasks/${idOf(foreignTask)}`, { cookie: coordinatorCookie })).status,
    ).toBe(404);
    expect(
      (await call(`/api/checklist-templates/${templateId}`, { cookie: outsiderCookie })).status,
    ).toBe(404);
    expect((await call(`/api/checklist-runs/${runId}`, { cookie: outsiderCookie })).status).toBe(
      404,
    );
    expect((await call(`/api/recurrences/${ruleId}`, { cookie: outsiderCookie })).status).toBe(404);

    const notices = await jsonOf(await call('/api/notifications', { cookie: volunteerCookie }));
    const items = notices.items as { id: string }[];
    noticeId = items[0]?.id ?? '';
    expect(noticeId).not.toBe('');
    const hidden = await call(`/api/notifications/${noticeId}/read`, {
      method: 'POST',
      cookie: outsiderCookie,
      body: {},
    });
    expect(hidden.status).toBe(404);
    expect(errorCode(await hidden.json())).toBe('not_found');
    const own = await call(`/api/notifications/${noticeId}/read`, {
      method: 'POST',
      cookie: volunteerCookie,
      body: {},
    });
    expect(own.status).toBe(200);
  });

  it('rifiuta payload extra, tipi errati, stringhe lunghe e date impossibili', async () => {
    const extra = await call('/api/tasks', {
      method: 'POST',
      cookie: coordinatorCookie,
      body: { ...taskBody('Sala', []), note: 'extra' },
    });
    expect(extra.status).toBe(400);
    expect(errorCode(await extra.json())).toBe('validation_error');

    const wrongType = await call('/api/tasks', {
      method: 'POST',
      cookie: coordinatorCookie,
      body: { ...taskBody('Sala', []), title: 12 },
    });
    expect(wrongType.status).toBe(400);

    const longTitle = await call('/api/tasks', {
      method: 'POST',
      cookie: coordinatorCookie,
      body: { ...taskBody('x'.repeat(161), []) },
    });
    expect(longTitle.status).toBe(400);

    const impossible = await call('/api/tasks', {
      method: 'POST',
      cookie: coordinatorCookie,
      body: { ...taskBody('Sala', []), dueAt: '2026-02-31T10:00:00.000Z' },
    });
    expect(impossible.status).toBe(400);
    expect(errorCode(await impossible.json())).toBe('validation_error');

    const auditDate = await call('/api/audit-logs?from=2026-02-31T00:00:00.000Z', {
      cookie: adminCookie,
    });
    expect(auditDate.status).toBe(400);
  });

  it('rifiuta un form cross-site senza l’intestazione richiesta', async () => {
    const response = await exports.default.fetch(
      new Request(`${ORIGIN}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'email=ada@example.org&password=segreto',
      }),
    );
    expect(response.status).toBe(403);
    expect(errorCode(await response.json())).toBe('csrf_rejected');
  });

  it('blocca il login dopo cinque tentativi falliti', async () => {
    for (let attempt = 0; attempt < 5; attempt += 1) {
      const response = await call('/api/auth/login', {
        method: 'POST',
        body: { email: 'sconosciuto-fase7@example.org', password: PASSWORD },
      });
      expect(response.status).toBe(401);
    }
    const limited = await call('/api/auth/login', {
      method: 'POST',
      body: { email: 'sconosciuto-fase7@example.org', password: PASSWORD },
    });
    expect(limited.status).toBe(429);
    expect(errorCode(await limited.json())).toBe('rate_limited');
    expect(limited.headers.get('Retry-After')).toBeTruthy();
  });

  it('aggiorna solo nome e preavviso e lascia i limiti di accesso', async () => {
    const forbidden = await call('/api/settings', { cookie: coordinatorCookie });
    expect(forbidden.status).toBe(403);
    const extra = await call('/api/settings', {
      method: 'PATCH',
      cookie: adminCookie,
      body: { associationName: 'Altro', loginMaxFailures: 1 },
    });
    expect(extra.status).toBe(400);
    const updated = await call('/api/settings', {
      method: 'PATCH',
      cookie: adminCookie,
      body: { associationName: 'Associazione Prova', dueSoonHours: 12 },
    });
    expect(updated.status).toBe(200);
    expect(await updated.json()).toEqual({
      associationName: 'Associazione Prova',
      dueSoonHours: 12,
    });
    const stored = await env.DB.prepare(
      `SELECT value FROM app_settings WHERE key = 'login_max_failures'`,
    ).first<{ value: string }>();
    expect(stored?.value).toBe('5');
    const me = await jsonOf(await call('/api/auth/me', { cookie: adminCookie }));
    expect(me.associationName).toBe('Associazione Prova');
  });

  it('neutralizza il CSV e lo limita al gruppo del coordinatore', async () => {
    const volunteer = await call('/api/exports/tasks.csv', { cookie: volunteerCookie });
    expect(volunteer.status).toBe(403);

    const coordinator = await call('/api/exports/tasks.csv', { cookie: coordinatorCookie });
    expect(coordinator.status).toBe(200);
    expect(coordinator.headers.get('Content-Type')).toContain('text/csv');
    const text = await csvText(coordinator);
    expect(text.startsWith('\uFEFF')).toBe(true);
    expect(text).toContain("'=SOMMA(1;1)");
    expect(text).not.toContain('Attività estranea');

    const admin = await call('/api/exports/tasks.csv', { cookie: adminCookie });
    const adminText = await csvText(admin);
    expect(adminText).toContain('Attività estranea');
    expect(adminText).toContain("'=SOMMA(1;1)");
  });

  it('registra le esportazioni e le modifiche', async () => {
    const logs = await jsonOf(
      await call('/api/audit-logs?action=export.tasks', { cookie: adminCookie }),
    );
    const items = logs.items as { action: string }[];
    expect(items.length).toBeGreaterThan(0);
    expect(items.every((item) => item.action === 'export.tasks')).toBe(true);
    const settings = await jsonOf(
      await call('/api/audit-logs?action=settings.updated', { cookie: adminCookie }),
    );
    expect((settings.items as unknown[]).length).toBeGreaterThan(0);
    const denied = await call('/api/audit-logs', { cookie: coordinatorCookie });
    expect(denied.status).toBe(403);
  });

  it('esporta il JSON, azzera il database e ripristina gli stessi record', async () => {
    const response = await call('/api/exports/backup', { cookie: adminCookie });
    expect(response.status).toBe(200);
    expect(response.headers.get('Cache-Control')).toContain('no-store');
    const coordinator = await call('/api/exports/backup', { cookie: coordinatorCookie });
    expect(coordinator.status).toBe(403);
    const document = (await response.json()) as BackupDocument;
    expect(document.version).toBe(1);
    expect(document.tables.sessions).toBeUndefined();
    expect(document.tables.invitation_tokens).toBeUndefined();
    expect(document.tables.auth_attempts).toBeUndefined();
    expect(document.tables.push_deliveries).toBeUndefined();
    const users = document.tables.users ?? [];
    const tasks = document.tables.tasks ?? [];
    const audits = document.tables.audit_logs ?? [];
    const exportedUser = users.find((row) => row.email === 'admin-fase7@example.org');
    const exportedTask = tasks.find((row) => row.title === '=SOMMA(1;1)');
    expect(typeof exportedUser?.password_hash).toBe('string');
    expect(exportedTask?.title).toBe('=SOMMA(1;1)');
    expect(audits.some((row) => row.action === 'export.backup')).toBe(true);

    for (const statement of backupStatements(document)) {
      await env.DB.prepare(statement).run();
    }

    for (const table of BACKUP_TABLES) {
      const count = await env.DB.prepare(`SELECT COUNT(*) AS n FROM ${table.name}`).first<{
        n: number;
      }>();
      expect(count?.n).toBe(document.tables[table.name]?.length);
    }
    for (const excluded of ['sessions', 'invitation_tokens', 'auth_attempts', 'push_deliveries']) {
      const count = await env.DB.prepare(`SELECT COUNT(*) AS n FROM ${excluded}`).first<{
        n: number;
      }>();
      expect(count?.n).toBe(0);
    }
    const user = await env.DB.prepare(
      `SELECT email, password_hash FROM users WHERE email = 'admin-fase7@example.org'`,
    ).first<{ email: string; password_hash: string }>();
    const task = await env.DB.prepare(`SELECT title FROM tasks WHERE title = '=SOMMA(1;1)'`).first<{
      title: string;
    }>();
    expect(user).toEqual({
      email: 'admin-fase7@example.org',
      password_hash: exportedUser?.password_hash,
    });
    expect(task?.title).toBe('=SOMMA(1;1)');
  });
});

function taskBody(title: string, assigneeIds: string[]): Record<string, unknown> {
  return {
    title,
    description: '',
    groupId,
    assigneeIds,
    priority: 'normal',
    dueAt: null,
  };
}

async function person(
  fullName: string,
  email: string,
  role: string,
  groupIds: string[],
): Promise<{ id: string; cookie: string }> {
  const response = await call('/api/users', {
    method: 'POST',
    cookie: adminCookie,
    body: { fullName, email, role, groupIds },
  });
  expect(response.status).toBe(201);
  const body = (await response.json()) as { user: { id: string }; inviteUrl: string };
  const accepted = await call('/api/auth/invitations/accept', {
    method: 'POST',
    body: { token: decodeURIComponent(new URL(body.inviteUrl).hash.slice(1)), password: PASSWORD },
  });
  return { id: body.user.id, cookie: cookieOf(accepted) };
}

async function call(
  path: string,
  options?: { method?: string; body?: unknown; cookie?: string },
): Promise<Response> {
  const method = options?.method ?? 'GET';
  const headers = new Headers();
  const writes = method !== 'GET' && method !== 'HEAD';
  if (writes) {
    headers.set('Content-Type', 'application/json');
    headers.set('X-Volontari-Request', '1');
    headers.set('Origin', ORIGIN);
  }
  if (options?.cookie) {
    headers.set('Cookie', `volontari_session=${options.cookie}`);
  }
  return exports.default.fetch(
    new Request(`${ORIGIN}${path}`, {
      method,
      headers,
      body: writes ? JSON.stringify(options?.body ?? {}) : null,
    }),
  );
}

function cookieOf(response: Response): string {
  const values =
    typeof response.headers.getSetCookie === 'function' ? response.headers.getSetCookie() : [];
  const header = values.find((value) => value.includes('volontari_session=')) ?? '';
  const match = /volontari_session=([^;]*)/.exec(header);
  if (!match?.[1]) {
    throw new Error('cookie mancante');
  }
  return match[1];
}

async function jsonOf(response: Response): Promise<Record<string, unknown>> {
  expect(response.status).toBeLessThan(300);
  return (await response.json()) as Record<string, unknown>;
}

function idOf(body: Record<string, unknown>): string {
  const id = body.id;
  if (typeof id !== 'string') {
    throw new Error('id mancante');
  }
  return id;
}

async function csvText(response: Response): Promise<string> {
  const bytes = new Uint8Array(await response.arrayBuffer());
  return new TextDecoder('utf-8', { fatal: false, ignoreBOM: true }).decode(bytes);
}

function errorCode(body: unknown): string | undefined {
  if (typeof body !== 'object' || body === null || !('error' in body)) {
    return undefined;
  }
  const error = (body as { error?: { code?: string } }).error;
  return error?.code;
}
