import { env, exports } from 'cloudflare:workers';
import { describe, expect, it } from 'vitest';
import { sha256Hex } from '../../src/worker/crypto';

const ORIGIN = 'http://volontari.test';
const BOOTSTRAP = 'token-di-collaudo-fase-2';
const PASSWORD = 'frase-di-prova-lunga';
const NEXT_PASSWORD = 'frase-di-prova-nuova';
const INVALID_CREDENTIALS = 'Credenziali non valide.';

let adminCookie = '';
let groupA = '';
let groupB = '';
let coordinatorCookie = '';
let volunteerCookie = '';
let volunteerId = '';

describe('accesso, utenti e gruppi', () => {
  it('dice che il portale non è ancora avviato', async () => {
    const response = await call('/api/setup');
    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toEqual({ initialized: false });
  });

  it('rifiuta una scrittura senza intestazione e con origine estranea', async () => {
    const missing = await call('/api/setup', {
      method: 'POST',
      body: {
        bootstrapToken: BOOTSTRAP,
        fullName: 'Ada Admin',
        email: 'admin@example.org',
        password: PASSWORD,
      },
      csrf: false,
    });
    expect(missing.status).toBe(403);
    expect(errorCode(await missing.json())).toBe('csrf_rejected');

    const foreign = await call('/api/auth/login', {
      method: 'POST',
      body: { email: 'admin@example.org', password: PASSWORD },
      origin: 'http://altro.test',
    });
    expect(foreign.status).toBe(403);
    expect(errorCode(await foreign.json())).toBe('csrf_rejected');
    await expect(call('/api/setup').then((response) => response.json())).resolves.toEqual({
      initialized: false,
    });
  });

  it('rifiuta una password corta e un codice di avvio errato', async () => {
    const short = await call('/api/setup', {
      method: 'POST',
      body: {
        bootstrapToken: BOOTSTRAP,
        fullName: 'Ada Admin',
        email: 'admin@example.org',
        password: '123456789012345',
      },
    });
    expect(short.status).toBe(400);
    expect(errorCode(await short.json())).toBe('validation_error');

    const wrong = await call('/api/setup', {
      method: 'POST',
      body: {
        bootstrapToken: 'codice-sbagliato',
        fullName: 'Ada Admin',
        email: 'admin@example.org',
        password: PASSWORD,
      },
    });
    expect(wrong.status).toBe(401);
    expect(errorCode(await wrong.json())).toBe('unauthenticated');
  });

  it('crea il primo amministratore e apre una sessione HttpOnly', async () => {
    const response = await call('/api/setup', {
      method: 'POST',
      body: {
        bootstrapToken: BOOTSTRAP,
        fullName: 'Ada Admin',
        email: 'Admin@Example.org',
        password: PASSWORD,
      },
    });
    expect(response.status).toBe(201);
    const cookie = readCookie(response);
    expect(cookie).toBeTruthy();
    const header = cookieHeader(response);
    expect(header).toContain('HttpOnly');
    expect(header).toContain('SameSite=Lax');
    expect(header).not.toMatch(/;\s*Secure/i);
    adminCookie = cookie ?? '';
    const body = await response.json();
    expect(body).toMatchObject({
      fullName: 'Ada Admin',
      email: 'admin@example.org',
      role: 'admin',
      status: 'active',
    });

    const sessionId = await sha256Hex(adminCookie);
    const stored = await env.DB.prepare('SELECT id FROM sessions WHERE id = ?')
      .bind(sessionId)
      .first();
    const raw = await env.DB.prepare('SELECT id FROM sessions WHERE id = ?')
      .bind(adminCookie)
      .first();
    expect(stored).not.toBeNull();
    expect(raw).toBeNull();

    const me = await call('/api/auth/me', { cookie: adminCookie });
    expect(me.status).toBe(200);
    await expect(me.json()).resolves.toMatchObject({ email: 'admin@example.org' });
  });

  it('rifiuta un secondo avvio anche con il codice giusto', async () => {
    const response = await call('/api/setup', {
      method: 'POST',
      body: {
        bootstrapToken: BOOTSTRAP,
        fullName: 'Altro',
        email: 'altro@example.org',
        password: PASSWORD,
      },
    });
    expect(response.status).toBe(404);
    expect(errorCode(await response.json())).toBe('not_found');
    await expect(call('/api/setup').then((item) => item.json())).resolves.toEqual({
      initialized: true,
    });
  });

  it('chiude la sessione e non accetta più il cookie', async () => {
    const response = await call('/api/auth/logout', { method: 'POST', cookie: adminCookie });
    expect(response.status).toBe(200);
    const me = await call('/api/auth/me', { cookie: adminCookie });
    expect(me.status).toBe(401);
    expect(errorCode(await me.json())).toBe('unauthenticated');
  });

  it('blocca il sesto tentativo e usa lo stesso messaggio per email sconosciute', async () => {
    for (let attempt = 0; attempt < 5; attempt += 1) {
      const response = await call('/api/auth/login', {
        method: 'POST',
        body: { email: 'blocco@example.org', password: PASSWORD },
      });
      expect(response.status).toBe(401);
      expect(errorMessage(await response.json())).toBe(INVALID_CREDENTIALS);
    }
    const limited = await call('/api/auth/login', {
      method: 'POST',
      body: { email: 'blocco@example.org', password: PASSWORD },
    });
    expect(limited.status).toBe(429);
    expect(errorCode(await limited.json())).toBe('rate_limited');
    expect(limited.headers.get('Retry-After')).toBeTruthy();

    const unknown = await call('/api/auth/login', {
      method: 'POST',
      body: { email: 'sconosciuto@example.org', password: PASSWORD },
    });
    const wrong = await call('/api/auth/login', {
      method: 'POST',
      body: { email: 'admin@example.org', password: 'frase-di-prova-errata' },
    });
    expect(unknown.status).toBe(401);
    expect(wrong.status).toBe(401);
    expect(errorMessage(await unknown.json())).toBe(INVALID_CREDENTIALS);
    expect(errorMessage(await wrong.json())).toBe(INVALID_CREDENTIALS);
  });

  it('fa entrare di nuovo l’amministratore', async () => {
    adminCookie = await login('admin@example.org', PASSWORD);
    const me = await call('/api/auth/me', { cookie: adminCookie });
    expect(me.status).toBe(200);
  });

  it('scade per inattività e per durata assoluta', async () => {
    const idleCookie = await login('admin@example.org', PASSWORD);
    const idleId = await sha256Hex(idleCookie);
    await env.DB.prepare('UPDATE sessions SET last_seen_at = ? WHERE id = ?')
      .bind(Date.now() - (12 * 60 * 60 * 1000 + 60_000), idleId)
      .run();
    const idle = await call('/api/auth/me', { cookie: idleCookie });
    expect(idle.status).toBe(401);
    const idleRow = await env.DB.prepare('SELECT revoked_at FROM sessions WHERE id = ?')
      .bind(idleId)
      .first<{
        revoked_at: number | null;
      }>();
    expect(idleRow?.revoked_at).not.toBeNull();

    const absoluteCookie = await login('admin@example.org', PASSWORD);
    const absoluteId = await sha256Hex(absoluteCookie);
    await env.DB.prepare('UPDATE sessions SET expires_at = ?, last_seen_at = ? WHERE id = ?')
      .bind(Date.now() - 1000, Date.now(), absoluteId)
      .run();
    expect((await call('/api/auth/me', { cookie: absoluteCookie })).status).toBe(401);
    adminCookie = await login('admin@example.org', PASSWORD);
  });

  it('crea i gruppi e le persone invitate', async () => {
    const first = await call('/api/groups', {
      method: 'POST',
      cookie: adminCookie,
      body: { name: 'Squadra A', description: 'Turno del mattino' },
    });
    const second = await call('/api/groups', {
      method: 'POST',
      cookie: adminCookie,
      body: { name: 'Squadra B', description: '' },
    });
    expect(first.status).toBe(201);
    expect(second.status).toBe(201);
    groupA = idOf(await first.json());
    groupB = idOf(await second.json());

    const coordinator = await call('/api/users', {
      method: 'POST',
      cookie: adminCookie,
      body: {
        fullName: 'Ciro Coord',
        email: 'coord@example.org',
        role: 'coordinator',
        groupIds: [groupA],
      },
    });
    const volunteer = await call('/api/users', {
      method: 'POST',
      cookie: adminCookie,
      body: {
        fullName: 'Vera Volontaria',
        email: 'volontario@example.org',
        role: 'volunteer',
        groupIds: [groupA],
      },
    });
    expect(coordinator.status).toBe(201);
    expect(volunteer.status).toBe(201);
    const coordinatorBody = (await coordinator.json()) as { inviteUrl: string };
    const volunteerBody = (await volunteer.json()) as { user: { id: string }; inviteUrl: string };
    expect(new URL(coordinatorBody.inviteUrl).search).toBe('');
    expect(new URL(coordinatorBody.inviteUrl).pathname).toBe('/attiva');
    volunteerId = volunteerBody.user.id;

    coordinatorCookie = await accept(coordinatorBody.inviteUrl);
    volunteerCookie = await accept(volunteerBody.inviteUrl);
    const repeat = await call('/api/auth/invitations/accept', {
      method: 'POST',
      body: { token: tokenFrom(volunteerBody.inviteUrl), password: PASSWORD },
    });
    expect(repeat.status).toBe(401);
  });

  it('rifiuta un invito scaduto, già disattivato o passato solo nella query', async () => {
    const expired = await invite('Enzo Scaduto', 'scaduto@example.org');
    await env.DB.prepare(
      `UPDATE invitation_tokens SET expires_at = 1 WHERE user_id = ? AND purpose = 'invite'`,
    )
      .bind(expired.id)
      .run();
    expect((await acceptResponse(expired.inviteUrl)).status).toBe(401);

    const disabled = await invite('Dina Spenta', 'spenta@example.org');
    expect(
      (await call(`/api/users/${disabled.id}/disable`, { method: 'POST', cookie: adminCookie }))
        .status,
    ).toBe(200);
    expect((await acceptResponse(disabled.inviteUrl)).status).toBe(401);
    const enable = await call(`/api/users/${disabled.id}/enable`, {
      method: 'POST',
      cookie: adminCookie,
    });
    expect(enable.status).toBe(409);

    const ignored = await call(
      `/api/auth/invitations/accept?token=${tokenFrom(expired.inviteUrl)}`,
      {
        method: 'POST',
        body: { password: PASSWORD },
      },
    );
    expect(ignored.status).toBe(400);
    const stillInvited = await env.DB.prepare('SELECT status FROM users WHERE id = ?')
      .bind(expired.id)
      .first<{
        status: string;
      }>();
    expect(stillInvited?.status).toBe('invited');
  });

  it('limita coordinatore e volontario al proprio perimetro', async () => {
    const coordinatorGroups = await call('/api/groups', { cookie: coordinatorCookie });
    expect(coordinatorGroups.status).toBe(200);
    const coordinatorBody = (await coordinatorGroups.json()) as { items: { id: string }[] };
    expect(coordinatorBody.items.map((item) => item.id)).toEqual([groupA]);

    const hidden = await call(`/api/groups/${groupB}/members`, { cookie: coordinatorCookie });
    expect(hidden.status).toBe(404);
    expect(errorCode(await hidden.json())).toBe('not_found');
    expect(
      (await call(`/api/groups/${groupA}/members`, { cookie: coordinatorCookie })).status,
    ).toBe(200);
    expect((await call('/api/users', { cookie: coordinatorCookie })).status).toBe(403);
    expect(
      (
        await call('/api/groups', {
          method: 'POST',
          cookie: coordinatorCookie,
          body: { name: 'Altro', description: '' },
        })
      ).status,
    ).toBe(403);

    const volunteerGroups = await call('/api/groups', { cookie: volunteerCookie });
    const volunteerBody = (await volunteerGroups.json()) as { items: { id: string }[] };
    expect(volunteerBody.items.map((item) => item.id)).toEqual([groupA]);
    expect((await call(`/api/groups/${groupB}/members`, { cookie: volunteerCookie })).status).toBe(
      404,
    );

    const roleChange = await call(`/api/users/${volunteerId}`, {
      method: 'PATCH',
      cookie: volunteerCookie,
      body: { fullName: 'Vera Volontaria', email: 'volontario@example.org', role: 'admin' },
    });
    expect(roleChange.status).toBe(403);
    const ownRole = await call('/api/me', {
      method: 'PATCH',
      cookie: volunteerCookie,
      body: { fullName: 'Vera Volontaria', role: 'admin' },
    });
    expect(ownRole.status).toBe(400);
    expect(errorCode(await ownRole.json())).toBe('validation_error');
  });

  it('non lascia l’associazione senza un amministratore attivo', async () => {
    const me = (await (await call('/api/auth/me', { cookie: adminCookie })).json()) as {
      id: string;
    };
    const disable = await call(`/api/users/${me.id}/disable`, {
      method: 'POST',
      cookie: adminCookie,
    });
    expect(disable.status).toBe(409);
    const demote = await call(`/api/users/${me.id}`, {
      method: 'PATCH',
      cookie: adminCookie,
      body: { fullName: 'Ada Admin', email: 'admin@example.org', role: 'volunteer' },
    });
    expect(demote.status).toBe(409);
    expect((await call('/api/auth/me', { cookie: adminCookie })).status).toBe(200);
  });

  it('ruota la sessione al cambio password e revoca le altre', async () => {
    const other = await login('admin@example.org', PASSWORD);
    const response = await call('/api/me/password', {
      method: 'POST',
      cookie: adminCookie,
      body: { currentPassword: PASSWORD, newPassword: NEXT_PASSWORD },
    });
    expect(response.status).toBe(200);
    const rotated = readCookie(response);
    expect(rotated).toBeTruthy();
    expect(rotated).not.toBe(adminCookie);
    expect((await call('/api/auth/me', { cookie: adminCookie })).status).toBe(401);
    expect((await call('/api/auth/me', { cookie: other })).status).toBe(401);
    adminCookie = rotated ?? '';
    expect((await call('/api/auth/me', { cookie: adminCookie })).status).toBe(200);
    expect(
      (
        await call('/api/auth/login', {
          method: 'POST',
          body: { email: 'admin@example.org', password: PASSWORD },
        })
      ).status,
    ).toBe(401);
  });

  it('conferma il reset senza aprire una sessione e revoca quelle esistenti', async () => {
    const issued = await call(`/api/users/${volunteerId}/password-reset`, {
      method: 'POST',
      cookie: adminCookie,
    });
    expect(issued.status).toBe(200);
    const resetUrl = ((await issued.json()) as { resetUrl: string }).resetUrl;
    expect(new URL(resetUrl).pathname).toBe('/reimposta-password');
    expect(new URL(resetUrl).search).toBe('');
    const response = await acceptResponse(
      resetUrl,
      '/api/auth/password-reset/confirm',
      NEXT_PASSWORD,
    );
    expect(response.status).toBe(200);
    expect(readCookie(response)).toBeNull();
    expect((await call('/api/auth/me', { cookie: volunteerCookie })).status).toBe(401);
    volunteerCookie = await login('volontario@example.org', NEXT_PASSWORD);
    expect((await call('/api/auth/me', { cookie: volunteerCookie })).status).toBe(200);
  });

  it('risponde allo stesso modo se la persona disattivata prova a entrare', async () => {
    const active = await invite('Nino Spento', 'spento@example.org');
    const cookie = await accept(active.inviteUrl);
    expect(
      (await call(`/api/users/${active.id}/disable`, { method: 'POST', cookie: adminCookie }))
        .status,
    ).toBe(200);
    expect((await call('/api/auth/me', { cookie })).status).toBe(401);
    const loginResponse = await call('/api/auth/login', {
      method: 'POST',
      body: { email: 'spento@example.org', password: PASSWORD },
    });
    expect(loginResponse.status).toBe(401);
    expect(errorMessage(await loginResponse.json())).toBe(INVALID_CREDENTIALS);
  });
});

async function call(
  path: string,
  options?: { method?: string; body?: unknown; cookie?: string; csrf?: boolean; origin?: string },
): Promise<Response> {
  const method = options?.method ?? 'GET';
  const headers = new Headers();
  const writes = method !== 'GET' && method !== 'HEAD';
  if (writes && options?.csrf !== false) {
    headers.set('Content-Type', 'application/json');
    headers.set('X-Volontari-Request', '1');
    headers.set('Origin', options?.origin ?? ORIGIN);
  }
  if (options?.cookie) {
    headers.set('Cookie', `volontari_session=${options.cookie}`);
  }
  return exports.default.fetch(
    new Request(`${ORIGIN}${path}`, {
      method,
      headers,
      body: writes ? JSON.stringify(options?.body ?? {}) : null,
    }),
  );
}

async function login(email: string, password: string): Promise<string> {
  const response = await call('/api/auth/login', { method: 'POST', body: { email, password } });
  expect(response.status).toBe(200);
  const cookie = readCookie(response);
  if (!cookie) {
    throw new Error('cookie mancante');
  }
  return cookie;
}

async function invite(fullName: string, email: string): Promise<{ id: string; inviteUrl: string }> {
  const response = await call('/api/users', {
    method: 'POST',
    cookie: adminCookie,
    body: { fullName, email, role: 'volunteer', groupIds: [] },
  });
  expect(response.status).toBe(201);
  const body = (await response.json()) as { user: { id: string }; inviteUrl: string };
  return { id: body.user.id, inviteUrl: body.inviteUrl };
}

async function accept(inviteUrl: string): Promise<string> {
  const response = await acceptResponse(inviteUrl);
  expect(response.status).toBe(200);
  const cookie = readCookie(response);
  if (!cookie) {
    throw new Error('cookie mancante');
  }
  return cookie;
}

function acceptResponse(
  inviteUrl: string,
  path = '/api/auth/invitations/accept',
  password = PASSWORD,
): Promise<Response> {
  return call(path, { method: 'POST', body: { token: tokenFrom(inviteUrl), password } });
}

function tokenFrom(url: string): string {
  return decodeURIComponent(new URL(url).hash.slice(1));
}

function readCookie(response: Response): string | null {
  const header = cookieHeader(response);
  const match = /volontari_session=([^;]*)/.exec(header);
  return match?.[1] ? match[1] : null;
}

function cookieHeader(response: Response): string {
  const values =
    typeof response.headers.getSetCookie === 'function' ? response.headers.getSetCookie() : [];
  return (
    values.find((value) => value.includes('volontari_session=')) ??
    response.headers.get('set-cookie') ??
    ''
  );
}

function errorCode(body: unknown): string | undefined {
  return errorRecord(body).code;
}

function errorMessage(body: unknown): string | undefined {
  return errorRecord(body).message;
}

function errorRecord(body: unknown): { code?: string; message?: string } {
  if (typeof body !== 'object' || body === null || !('error' in body)) {
    return {};
  }
  const error = (body as { error?: unknown }).error;
  if (typeof error !== 'object' || error === null) {
    return {};
  }
  const record = error as { code?: unknown; message?: unknown };
  return {
    ...(typeof record.code === 'string' ? { code: record.code } : {}),
    ...(typeof record.message === 'string' ? { message: record.message } : {}),
  };
}

function idOf(body: unknown): string {
  if (
    typeof body === 'object' &&
    body !== null &&
    'id' in body &&
    typeof (body as { id?: unknown }).id === 'string'
  ) {
    return (body as { id: string }).id;
  }
  throw new Error('id mancante');
}
