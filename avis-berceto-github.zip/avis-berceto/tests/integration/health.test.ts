import { env, exports } from 'cloudflare:workers';
import { describe, expect, it } from 'vitest';

describe('GET /api/health', () => {
  it('risponde che il database migrato è collegato', async () => {
    const response = await exports.default.fetch(new Request('http://volontari.test/api/health'));
    expect(response.status).toBe(200);
    const body: unknown = await response.json();
    expect(body).toMatchObject({
      status: 'ok',
      service: 'volontari',
      database: 'ok',
    });
    expect(env.DB).toBeDefined();
  });

  it('risponde 404 JSON per un percorso API sconosciuto', async () => {
    const response = await exports.default.fetch(
      new Request('http://volontari.test/api/inesistente'),
    );
    expect(response.status).toBe(404);
    await expect(response.json()).resolves.toEqual({
      error: { code: 'not_found', message: 'Risorsa non trovata.' },
    });
  });
});
