import { env, exports } from 'cloudflare:workers';
import { describe, expect, it } from 'vitest';
import { cleanupAuthRecords } from '../../src/worker/cleanup';
import { createDeadlineNotices, drainPush, type PushPayload } from '../../src/worker/notifications';

const ORIGIN = 'http://volontari.test';
const BOOTSTRAP = 'token-di-collaudo-fase-2';
const PASSWORD = 'frase-di-prova-lunga';
const HOUR = 60 * 60 * 1000;

let adminCookie = '';
let coordinatorCookie = '';
let volunteerCookie = '';
let outsiderCookie = '';
let groupId = '';
let otherGroupId = '';
let coordinatorId = '';
let volunteerId = '';
let outsiderId = '';

describe('notifiche e push', () => {
  it('prepara le persone', async () => {
    const setup = await call('/api/setup', {
      method: 'POST',
      body: {
        bootstrapToken: BOOTSTRAP,
        fullName: 'Ada Admin',
        email: 'admin-notifiche@example.org',
        password: PASSWORD,
      },
    });
    adminCookie = cookieOf(setup);
    groupId = idOf(
      await jsonOf(
        await call('/api/groups', {
          method: 'POST',
          cookie: adminCookie,
          body: { name: 'Squadra Notifiche', description: '' },
        }),
      ),
    );
    otherGroupId = idOf(
      await jsonOf(
        await call('/api/groups', {
          method: 'POST',
          cookie: adminCookie,
          body: { name: 'Squadra Altra', description: '' },
        }),
      ),
    );
    const coordinator = await person('Ciro Coord', 'ciro-notifiche@example.org', 'coordinator', [
      groupId,
    ]);
    const volunteer = await person('Vera Volontaria', 'vera-notifiche@example.org', 'volunteer', [
      groupId,
    ]);
    const outsider = await person('Nino Esterno', 'nino-notifiche@example.org', 'volunteer', [
      otherGroupId,
    ]);
    coordinatorId = coordinator.id;
    volunteerId = volunteer.id;
    outsiderId = outsider.id;
    coordinatorCookie = coordinator.cookie;
    volunteerCookie = volunteer.cookie;
    outsiderCookie = outsider.cookie;
  });

  it('avvisa l’assegnatario e non un estraneo, una volta sola', async () => {
    const taskId = await createTask('Controllo estintori', [volunteerId]);
    const volunteer = await notices(volunteerCookie);
    expect(volunteer.unread).toBe(1);
    expect(volunteer.items).toEqual([
      expect.objectContaining({
        type: 'task_assigned',
        title: 'Nuova attività',
        body: 'Controllo estintori',
        path: `/attivita/${taskId}`,
      }),
    ]);
    expect((await notices(outsiderCookie)).items).toEqual([]);
    expect((await notices(adminCookie)).items).toEqual([]);

    await patchTask(taskId, 'Controllo estintori', []);
    await patchTask(taskId, 'Controllo estintori', [volunteerId]);
    expect(await countNotices(volunteerId, taskId, 'task_assigned', 'assigned')).toBe(1);

    const foreign = await call(`/api/notifications/${volunteer.items[0]?.id}/read`, {
      method: 'POST',
      cookie: outsiderCookie,
    });
    expect(foreign.status).toBe(404);
    const read = await call(`/api/notifications/${volunteer.items[0]?.id}/read`, {
      method: 'POST',
      cookie: volunteerCookie,
    });
    expect(read.status).toBe(200);
    expect(await read.json()).toMatchObject({ readAt: expect.any(String) });
    expect((await notices(volunteerCookie)).unread).toBe(0);
  });

  it('avvisa i coordinatori quando l’attività o la checklist si chiude', async () => {
    const taskId = await createTask('Chiudere la sala', [volunteerId]);
    const completed = await call(`/api/tasks/${taskId}/complete`, {
      method: 'POST',
      cookie: volunteerCookie,
    });
    expect(completed.status).toBe(200);
    const coordinator = await notices(coordinatorCookie);
    expect(coordinator.items).toEqual([
      expect.objectContaining({
        type: 'task_completed',
        body: 'Chiudere la sala',
        path: `/attivita/${taskId}`,
      }),
    ]);
    expect(
      (await notices(volunteerCookie)).items.some((item) => item.type === 'task_completed'),
    ).toBe(false);

    const template = await jsonOf(
      await call('/api/checklist-templates', {
        method: 'POST',
        cookie: coordinatorCookie,
        body: {
          title: 'Controllo FOO',
          description: '',
          groupId,
          items: [{ label: 'Estintore', helpText: '', required: true }],
        },
      }),
    );
    const run = await jsonOf(
      await call(`/api/checklist-templates/${idOf(template)}/runs`, {
        method: 'POST',
        cookie: volunteerCookie,
        body: {},
      }),
    );
    const runId = idOf(run);
    const itemId = (run.items as { id: string }[])[0]?.id ?? '';
    const marked = await call(`/api/checklist-runs/${runId}/items/${itemId}`, {
      method: 'PATCH',
      cookie: volunteerCookie,
      body: { result: 'compliant', note: '' },
    });
    expect(marked.status).toBe(200);
    const closed = await call(`/api/checklist-runs/${runId}/complete`, {
      method: 'POST',
      cookie: volunteerCookie,
    });
    expect(closed.status).toBe(200);
    const after = await notices(coordinatorCookie);
    expect(
      after.items.some(
        (item) =>
          item.type === 'checklist_completed' && item.path === `/checklist/esecuzioni/${runId}`,
      ),
    ).toBe(true);
    expect(
      (await notices(volunteerCookie)).items.some((item) => item.type === 'checklist_completed'),
    ).toBe(false);
    const readAll = await call('/api/notifications/read-all', {
      method: 'POST',
      cookie: coordinatorCookie,
    });
    expect(readAll.status).toBe(200);
    expect((await notices(coordinatorCookie)).unread).toBe(0);
    expect((await notices(volunteerCookie)).unread).toBeGreaterThan(0);
  });

  it('crea in scadenza e scaduta una sola volta, anche senza assegnatari', async () => {
    const now = Date.parse('2026-11-23T10:00:00.000Z');
    const soonId = await createTask(
      'In scadenza',
      [volunteerId],
      new Date(now + HOUR).toISOString(),
    );
    const lateId = await createTask('Scaduta', [volunteerId], new Date(now - HOUR).toISOString());
    const openId = await createTask('Senza assegnatari', [], new Date(now + HOUR).toISOString());
    expect(await createDeadlineNotices(env.DB, now, 24 * HOUR)).toBeGreaterThan(0);
    expect(await createDeadlineNotices(env.DB, now, 24 * HOUR)).toBe(0);
    expect(await countNotices(volunteerId, soonId, 'task_due_soon', 'due-soon')).toBe(1);
    expect(await countNotices(volunteerId, lateId, 'task_overdue', 'overdue')).toBe(1);
    expect(await countNotices(volunteerId, openId, 'task_due_soon', 'due-soon')).toBe(1);
    expect(await countNotices(coordinatorId, openId, 'task_due_soon', 'due-soon')).toBe(1);
    expect(await countNotices(outsiderId, openId, 'task_due_soon', 'due-soon')).toBe(0);
    expect(await countNotices(volunteerId, soonId, 'task_overdue', 'overdue')).toBe(0);
  });

  it('mette in coda il percorso, riprova un 503 e dimentica un 410', async () => {
    const endpoint = 'https://push.example.test/vera';
    const subscribed = await call('/api/push/subscriptions', {
      method: 'POST',
      cookie: volunteerCookie,
      body: { endpoint, keys: { p256dh: 'chiave-dispositivo', auth: 'segreto-dispositivo' } },
    });
    expect(subscribed.status).toBe(201);
    const subscriptionId = idOf(await jsonOf(subscribed));
    const rebound = await call('/api/push/subscriptions', {
      method: 'POST',
      cookie: coordinatorCookie,
      body: { endpoint, keys: { p256dh: 'chiave-dispositivo', auth: 'segreto-dispositivo' } },
    });
    expect(rebound.status).toBe(201);
    expect(idOf(await jsonOf(rebound))).toBe(subscriptionId);
    const owner = await env.DB.prepare('SELECT user_id FROM push_subscriptions WHERE id = ?')
      .bind(subscriptionId)
      .first<{ user_id: string }>();
    expect(owner?.user_id).toBe(coordinatorId);
    const denied = await call(`/api/push/subscriptions/${subscriptionId}`, {
      method: 'DELETE',
      cookie: volunteerCookie,
    });
    expect(denied.status).toBe(404);

    const payloads: PushPayload[] = [];
    const taskId = await createTask('Consegna push', [coordinatorId]);
    const delivery = await env.DB.prepare(
      `SELECT d.id, d.status FROM push_deliveries d
       JOIN notifications n ON n.id = d.notification_id
       WHERE n.resource_id = ? AND d.subscription_id = ?`,
    )
      .bind(taskId, subscriptionId)
      .first<{ id: string; status: string }>();
    expect(delivery?.status).toBe('pending');
    const sent = await drainPush(env.DB, Date.now(), {
      encoder: async (payload) => {
        payloads.push(payload);
        return { method: 'POST' };
      },
      sender: async () => ({ status: 201 }),
    });
    expect(sent).toBe(1);
    expect(payloads[0]).toMatchObject({
      title: 'Nuova attività',
      body: 'Consegna push',
      path: `/attivita/${taskId}`,
    });
    expect(payloads[0]?.path).not.toBe(payloads[0]?.title);
    const after = await env.DB.prepare('SELECT status FROM push_deliveries WHERE id = ?')
      .bind(delivery?.id)
      .first<{ status: string }>();
    expect(after?.status).toBe('sent');

    const retryEndpoint = 'https://push.example.test/retry';
    const retry = await jsonOf(
      await call('/api/push/subscriptions', {
        method: 'POST',
        cookie: volunteerCookie,
        body: { endpoint: retryEndpoint, keys: { p256dh: 'chiave-retry', auth: 'segreto-retry' } },
      }),
    );
    const retryTask = await createTask('Consegna da riprovare', [volunteerId]);
    let now = Date.now();
    const delays = [15 * 60 * 1000, 60 * 60 * 1000, 6 * 60 * 60 * 1000];
    for (const [index, delay] of delays.entries()) {
      const started = now;
      await drainPush(env.DB, now, {
        encoder: async () => ({ method: 'POST' }),
        sender: async () => ({ status: 503 }),
      });
      const row = await deliveryOf(retryTask, idOf(retry));
      expect(row.status).toBe('failed');
      expect(row.attempts).toBe(index + 1);
      expect(row.next_attempt_at - started).toBe(delay);
      now = row.next_attempt_at;
    }
    await drainPush(env.DB, now, {
      encoder: async () => ({ method: 'POST' }),
      sender: async () => ({ status: 503 }),
    });
    expect((await deliveryOf(retryTask, idOf(retry))).status).toBe('abandoned');

    const goneEndpoint = 'https://push.example.test/gone';
    const gone = await jsonOf(
      await call('/api/push/subscriptions', {
        method: 'POST',
        cookie: volunteerCookie,
        body: { endpoint: goneEndpoint, keys: { p256dh: 'chiave-gone', auth: 'segreto-gone' } },
      }),
    );
    await createTask('Consegna scaduta', [volunteerId]);
    await drainPush(env.DB, Date.now(), {
      encoder: async () => ({ method: 'POST' }),
      sender: async () => ({ status: 410 }),
    });
    const remaining = await env.DB.prepare('SELECT id FROM push_subscriptions WHERE id = ?')
      .bind(idOf(gone))
      .first();
    expect(remaining).toBeNull();

    const removed = await call(`/api/push/subscriptions/${subscriptionId}`, {
      method: 'DELETE',
      cookie: coordinatorCookie,
    });
    expect(removed.status).toBe(200);
  });

  it('restituisce solo la chiave pubblica e pulisce il vecchio', async () => {
    const key = await call('/api/push/vapid-public-key', { cookie: volunteerCookie });
    expect(key.status).toBe(200);
    const body = (await key.json()) as { publicKey: string };
    expect(body).toEqual({ publicKey: 'chiave-pubblica-di-collaudo' });
    expect(JSON.stringify(body)).not.toContain('PRIVATE');

    const now = Date.now();
    const day = 24 * 60 * 60 * 1000;
    const oldNotice = crypto.randomUUID();
    const freshNotice = crypto.randomUUID();
    const oldDelivery = crypto.randomUUID();
    const oldAttempt = crypto.randomUUID();
    const freshAttempt = crypto.randomUUID();
    await env.DB.batch([
      env.DB.prepare(
        `INSERT INTO notifications (
           id, user_id, type, title, body, resource_type, resource_id, dedup_key, created_at
         ) VALUES (?, ?, 'task_assigned', 'Vecchia', 'Vecchia', 'task', ?, 'old', ?)`,
      ).bind(oldNotice, volunteerId, crypto.randomUUID(), now - 181 * day),
      env.DB.prepare(
        `INSERT INTO notifications (
           id, user_id, type, title, body, resource_type, resource_id, dedup_key, created_at
         ) VALUES (?, ?, 'task_assigned', 'Recente', 'Recente', 'task', ?, 'fresh', ?)`,
      ).bind(freshNotice, volunteerId, crypto.randomUUID(), now),
      env.DB.prepare(
        `INSERT INTO push_subscriptions (
           id, user_id, endpoint, p256dh, auth_key, created_at, failure_count
         ) VALUES (?, ?, ?, 'chiave', 'segreto', ?, 0)`,
      ).bind(crypto.randomUUID(), volunteerId, 'https://push.example.test/archivio', now),
      env.DB.prepare(
        `INSERT INTO push_deliveries (
           id, notification_id, subscription_id, status, attempts, next_attempt_at, created_at, updated_at
         )
         SELECT ?, ?, id, 'sent', 1, ?, ?, ?
         FROM push_subscriptions WHERE endpoint = ?`,
      ).bind(
        oldDelivery,
        freshNotice,
        now,
        now - 31 * day,
        now - 31 * day,
        'https://push.example.test/archivio',
      ),
      env.DB.prepare(
        `INSERT INTO auth_attempts (id, scope, subject_hash, attempted_at, success)
         VALUES (?, 'login', 'vecchio', ?, 0)`,
      ).bind(oldAttempt, now - 3 * day),
      env.DB.prepare(
        `INSERT INTO auth_attempts (id, scope, subject_hash, attempted_at, success)
         VALUES (?, 'login', 'recente', ?, 0)`,
      ).bind(freshAttempt, now),
    ]);
    await cleanupAuthRecords(env.DB, now);
    expect(
      await env.DB.prepare('SELECT id FROM notifications WHERE id = ?').bind(oldNotice).first(),
    ).toBeNull();
    expect(
      await env.DB.prepare('SELECT id FROM notifications WHERE id = ?').bind(freshNotice).first(),
    ).not.toBeNull();
    expect(
      await env.DB.prepare('SELECT id FROM push_deliveries WHERE id = ?').bind(oldDelivery).first(),
    ).toBeNull();
    expect(
      await env.DB.prepare('SELECT id FROM auth_attempts WHERE id = ?').bind(oldAttempt).first(),
    ).toBeNull();
    expect(
      await env.DB.prepare('SELECT id FROM auth_attempts WHERE id = ?').bind(freshAttempt).first(),
    ).not.toBeNull();
  });
});

async function createTask(
  title: string,
  assigneeIds: string[],
  dueAt: string | null = null,
): Promise<string> {
  const response = await call('/api/tasks', {
    method: 'POST',
    cookie: adminCookie,
    body: {
      title,
      description: '',
      groupId,
      assigneeIds,
      priority: 'normal',
      dueAt,
    },
  });
  expect(response.status).toBe(201);
  return idOf(await jsonOf(response));
}

async function patchTask(taskId: string, title: string, assigneeIds: string[]): Promise<void> {
  const response = await call(`/api/tasks/${taskId}`, {
    method: 'PATCH',
    cookie: adminCookie,
    body: { title, description: '', assigneeIds, priority: 'normal', dueAt: null },
  });
  expect(response.status).toBe(200);
}

async function notices(cookie: string): Promise<{
  unread: number;
  items: {
    id: string;
    type: string;
    title: string;
    body: string;
    path: string;
    readAt: string | null;
  }[];
}> {
  const response = await call('/api/notifications', { cookie });
  expect(response.status).toBe(200);
  return (await response.json()) as Awaited<ReturnType<typeof notices>>;
}

async function countNotices(
  userId: string,
  resourceId: string,
  type: string,
  dedupKey: string,
): Promise<number> {
  const row = await env.DB.prepare(
    `SELECT COUNT(*) AS n FROM notifications
     WHERE user_id = ? AND resource_id = ? AND type = ? AND dedup_key = ?`,
  )
    .bind(userId, resourceId, type, dedupKey)
    .first<{ n: number }>();
  return Number(row?.n ?? 0);
}

async function deliveryOf(
  taskId: string,
  subscriptionId: string,
): Promise<{ status: string; attempts: number; next_attempt_at: number }> {
  const row = await env.DB.prepare(
    `SELECT d.status, d.attempts, d.next_attempt_at
     FROM push_deliveries d
     JOIN notifications n ON n.id = d.notification_id
     WHERE n.resource_id = ? AND d.subscription_id = ?`,
  )
    .bind(taskId, subscriptionId)
    .first<{ status: string; attempts: number; next_attempt_at: number }>();
  if (!row) {
    throw new Error('consegna mancante');
  }
  return row;
}

async function person(
  fullName: string,
  email: string,
  role: string,
  groupIds: string[],
): Promise<{ id: string; cookie: string }> {
  const response = await call('/api/users', {
    method: 'POST',
    cookie: adminCookie,
    body: { fullName, email, role, groupIds },
  });
  expect(response.status).toBe(201);
  const body = (await response.json()) as { user: { id: string }; inviteUrl: string };
  const accepted = await call('/api/auth/invitations/accept', {
    method: 'POST',
    body: { token: decodeURIComponent(new URL(body.inviteUrl).hash.slice(1)), password: PASSWORD },
  });
  expect(accepted.status).toBe(200);
  return { id: body.user.id, cookie: cookieOf(accepted) };
}

async function call(
  path: string,
  options?: { method?: string; body?: unknown; cookie?: string },
): Promise<Response> {
  const method = options?.method ?? 'GET';
  const headers = new Headers();
  const writes = method !== 'GET' && method !== 'HEAD';
  if (writes) {
    headers.set('Content-Type', 'application/json');
    headers.set('X-Volontari-Request', '1');
    headers.set('Origin', ORIGIN);
  }
  if (options?.cookie) {
    headers.set('Cookie', `volontari_session=${options.cookie}`);
  }
  return exports.default.fetch(
    new Request(`${ORIGIN}${path}`, {
      method,
      headers,
      body: writes ? JSON.stringify(options?.body ?? {}) : null,
    }),
  );
}

function cookieOf(response: Response): string {
  const values =
    typeof response.headers.getSetCookie === 'function' ? response.headers.getSetCookie() : [];
  const header =
    values.find((value) => value.includes('volontari_session=')) ??
    response.headers.get('set-cookie') ??
    '';
  const match = /volontari_session=([^;]*)/.exec(header);
  if (!match?.[1]) {
    throw new Error('cookie mancante');
  }
  return match[1];
}

async function jsonOf(response: Response): Promise<Record<string, unknown>> {
  expect(response.status).toBeGreaterThanOrEqual(200);
  expect(response.status).toBeLessThan(300);
  return (await response.json()) as Record<string, unknown>;
}

function idOf(body: Record<string, unknown>): string {
  if (typeof body.id === 'string') {
    return body.id;
  }
  const user = body.user;
  if (typeof user === 'object' && user !== null && 'id' in user && typeof user.id === 'string') {
    return user.id;
  }
  throw new Error('id mancante');
}
