import { env, exports } from 'cloudflare:workers';
import { describe, expect, it } from 'vitest';

const ORIGIN = 'http://volontari.test';
const BOOTSTRAP = 'token-di-collaudo-fase-2';
const PASSWORD = 'frase-di-prova-lunga';
const CONFLICT = "Lo stato dell'attività è cambiato. Aggiorna la pagina.";
const HOUR = 60 * 60 * 1000;

let adminCookie = '';
let coordinatorCookie = '';
let volunteerCookie = '';
let outsiderCookie = '';
let groupA = '';
let groupB = '';
let volunteerId = '';
let outsiderId = '';
let coordinatorId = '';
let mainTaskId = '';

describe('attività e dashboard', () => {
  it('prepara amministratore, gruppi e persone', async () => {
    const setup = await call('/api/setup', {
      method: 'POST',
      body: {
        bootstrapToken: BOOTSTRAP,
        fullName: 'Ada Admin',
        email: 'admin@example.org',
        password: PASSWORD,
      },
    });
    adminCookie = cookieOf(setup);
    groupA = idOf(
      await jsonOf(
        await call('/api/groups', {
          method: 'POST',
          cookie: adminCookie,
          body: { name: 'Squadra Alfa', description: '' },
        }),
      ),
    );
    groupB = idOf(
      await jsonOf(
        await call('/api/groups', {
          method: 'POST',
          cookie: adminCookie,
          body: { name: 'Squadra Beta', description: '' },
        }),
      ),
    );
    const coordinator = await person('Ciro Coord', 'ciro@example.org', 'coordinator', [groupA]);
    const volunteer = await person('Vera Volontaria', 'vera@example.org', 'volunteer', [groupA]);
    const outsider = await person('Nino Esterno', 'nino@example.org', 'volunteer', [groupB]);
    coordinatorId = coordinator.id;
    volunteerId = volunteer.id;
    outsiderId = outsider.id;
    coordinatorCookie = coordinator.cookie;
    volunteerCookie = volunteer.cookie;
    outsiderCookie = outsider.cookie;
  });

  it('crea, assegna, prende in carico e completa', async () => {
    const created = await call('/api/tasks', {
      method: 'POST',
      cookie: adminCookie,
      body: taskBody({ title: 'Preparare la sala' }),
    });
    expect(created.status).toBe(201);
    const task = (await created.json()) as TaskBody;
    mainTaskId = task.id;
    expect(task.status).toBe('todo');
    expect(task.groupId).toBe(groupA);

    expect((await call(`/api/tasks/${mainTaskId}`, { cookie: coordinatorCookie })).status).toBe(
      200,
    );
    const volunteerCreate = await call('/api/tasks', {
      method: 'POST',
      cookie: volunteerCookie,
      body: taskBody({ title: 'Non consentita' }),
    });
    expect(volunteerCreate.status).toBe(403);
    const volunteerPatch = await call(`/api/tasks/${mainTaskId}`, {
      method: 'PATCH',
      cookie: volunteerCookie,
      body: patchBody({ title: 'Titolo del volontario' }),
    });
    expect(volunteerPatch.status).toBe(403);
    expect(
      ((await (await call(`/api/tasks/${mainTaskId}`, { cookie: adminCookie })).json()) as TaskBody)
        .title,
    ).toBe('Preparare la sala');

    const edited = await call(`/api/tasks/${mainTaskId}`, {
      method: 'PATCH',
      cookie: coordinatorCookie,
      body: patchBody({ title: 'Preparare la sala grande', assigneeIds: [volunteerId] }),
    });
    expect(edited.status).toBe(200);
    expect(await edited.json()).toMatchObject({
      title: 'Preparare la sala grande',
      assignees: [expect.objectContaining({ id: volunteerId })],
    });

    const claimed = await call(`/api/tasks/${mainTaskId}/claim`, {
      method: 'POST',
      cookie: volunteerCookie,
    });
    expect(claimed.status).toBe(200);
    expect(await claimed.json()).toMatchObject({ status: 'in_progress', claimedBy: volunteerId });

    const completed = await call(`/api/tasks/${mainTaskId}/complete`, {
      method: 'POST',
      cookie: volunteerCookie,
    });
    expect(completed.status).toBe(200);
    expect(await completed.json()).toMatchObject({ status: 'completed', completedBy: volunteerId });
  });

  it('rifiuta un assegnatario fuori dal gruppo senza lasciare righe', async () => {
    const before = await count('tasks');
    const response = await call('/api/tasks', {
      method: 'POST',
      cookie: adminCookie,
      body: taskBody({
        title: 'Assegnazione mista',
        assigneeIds: [volunteerId, outsiderId],
      }),
    });
    expect(response.status).toBe(400);
    expect(errorMessage(await response.json())).toBe(
      'Gli assegnatari devono essere membri attivi del gruppo.',
    );
    expect(await count('tasks')).toBe(before);
    const titled = await env.DB.prepare('SELECT id FROM tasks WHERE title = ?')
      .bind('Assegnazione mista')
      .first();
    expect(titled).toBeNull();
  });

  it('aggiorna la dashboard dei tre ruoli e la lista', async () => {
    const volunteerHome = await dashboard(volunteerCookie);
    expect(volunteerHome.personal).toEqual(zeros());
    expect(volunteerHome.group).toBeNull();
    expect(volunteerHome.notifications).toEqual([
      expect.objectContaining({
        title: 'Nuova attività',
        body: 'Preparare la sala grande',
        path: `/attivita/${mainTaskId}`,
      }),
    ]);
    expect(await dashboard(coordinatorCookie)).toMatchObject({
      personal: zeros(),
      notifications: [
        expect.objectContaining({
          title: 'Attività completata',
          body: 'Preparare la sala grande',
          path: `/attivita/${mainTaskId}`,
        }),
      ],
      group: {
        open: 0,
        overdue: 0,
        completedLast30Days: 1,
        checklistsInProgress: 0,
        assignments: [
          { userId: coordinatorId, fullName: 'Ciro Coord', openTasks: 0 },
          { userId: volunteerId, fullName: 'Vera Volontaria', openTasks: 0 },
        ],
      },
    });
    expect(await dashboard(adminCookie)).toMatchObject({
      group: {
        open: 0,
        overdue: 0,
        completedLast30Days: 1,
        checklistsInProgress: 0,
        assignments: [
          { userId: coordinatorId, openTasks: 0 },
          { userId: outsiderId, openTasks: 0 },
          { userId: volunteerId, openTasks: 0 },
        ],
      },
    });

    const listed = await call('/api/tasks?status=completed', { cookie: volunteerCookie });
    expect(listed.status).toBe(200);
    const body = (await listed.json()) as {
      items: { id: string; status: string }[];
      total: number;
    };
    expect(body.total).toBe(1);
    expect(body.items.map((item) => item.id)).toEqual([mainTaskId]);
    const again = await call('/api/tasks?status=completed', { cookie: adminCookie });
    expect(((await again.json()) as { items: { id: string }[] }).items[0]?.id).toBe(mainTaskId);
  });

  it('registra creazione, presa in carico e completamento', async () => {
    const history = await call(`/api/tasks/${mainTaskId}/history`, { cookie: volunteerCookie });
    expect(history.status).toBe(200);
    const actions = ((await history.json()) as { items: { action: string }[] }).items.map(
      (item) => item.action,
    );
    expect(actions).toEqual(['task.created', 'task.updated', 'task.claimed', 'task.completed']);
  });

  it('conta le scadute, esclude chi non ha scadenza e nasconde l’altro gruppo', async () => {
    const past = new Date(Date.now() - HOUR).toISOString();
    const soon = new Date(Date.now() + HOUR).toISOString();
    const foreign = await call('/api/tasks', {
      method: 'POST',
      cookie: adminCookie,
      body: taskBody({
        title: 'Fuori perimetro',
        groupId: groupB,
        assigneeIds: [outsiderId],
        priority: 'urgent',
        dueAt: past,
      }),
    });
    const foreignId = idOf(await foreign.json());
    const hidden = await call(`/api/tasks/${foreignId}`, { cookie: volunteerCookie });
    const missing = await call(`/api/tasks/${crypto.randomUUID()}`, { cookie: volunteerCookie });
    expect(hidden.status).toBe(404);
    expect(missing.status).toBe(404);
    expect(await hidden.json()).toEqual(await missing.json());
    const volunteerPatch = await call(`/api/tasks/${foreignId}`, {
      method: 'PATCH',
      cookie: volunteerCookie,
      body: patchBody({ title: 'Fuori' }),
    });
    const coordinatorPatch = await call(`/api/tasks/${foreignId}`, {
      method: 'PATCH',
      cookie: coordinatorCookie,
      body: patchBody({ title: 'Fuori' }),
    });
    expect(volunteerPatch.status).toBe(404);
    expect(coordinatorPatch.status).toBe(404);
    expect((await call(`/api/tasks?groupId=${groupB}`, { cookie: volunteerCookie })).status).toBe(
      200,
    );
    await expect(
      call(`/api/tasks?groupId=${groupB}`, { cookie: volunteerCookie }).then((response) =>
        response.json(),
      ),
    ).resolves.toMatchObject({ items: [], total: 0 });

    await call('/api/tasks', {
      method: 'POST',
      cookie: coordinatorCookie,
      body: taskBody({
        title: 'Già scaduta',
        assigneeIds: [volunteerId],
        priority: 'urgent',
        dueAt: past,
      }),
    });
    await call('/api/tasks', {
      method: 'POST',
      cookie: adminCookie,
      body: taskBody({ title: 'Senza scadenza', dueAt: null }),
    });
    await call('/api/tasks', {
      method: 'POST',
      cookie: adminCookie,
      body: taskBody({ title: 'Entro domani', dueAt: soon }),
    });

    const volunteer = await dashboard(volunteerCookie);
    expect(volunteer.group).toBeNull();
    expect(volunteer.personal).toEqual({
      assignedOpen: 1,
      claimable: 2,
      urgentOpen: 1,
      overdue: 1,
      dueSoon: 1,
      openChecklists: 0,
    });
    const coordinator = await dashboard(coordinatorCookie);
    expect(coordinator.group).toMatchObject({
      open: 3,
      overdue: 1,
      completedLast30Days: 1,
      checklistsInProgress: 0,
    });
    expect(
      coordinator.group?.assignments.find((person) => person.userId === volunteerId)?.openTasks,
    ).toBe(1);
    const admin = await dashboard(adminCookie);
    expect(admin.group).toMatchObject({ open: 4, overdue: 2, completedLast30Days: 1 });
    expect(admin.personal.overdue).toBe(2);
    expect(admin.personal.dueSoon).toBe(1);
  });

  it('filtra, ordina e risponde vuoto oltre l’ultima pagina', async () => {
    const due = Date.now() + 2 * 24 * HOUR;
    await call('/api/tasks', {
      method: 'POST',
      cookie: adminCookie,
      body: taskBody({
        title: 'Alfa filtro',
        priority: 'low',
        dueAt: new Date(due).toISOString(),
      }),
    });
    await call('/api/tasks', {
      method: 'POST',
      cookie: adminCookie,
      body: taskBody({
        title: 'Zeta filtro',
        priority: 'high',
        assigneeIds: [volunteerId],
        dueAt: new Date(due + 24 * HOUR).toISOString(),
      }),
    });
    await call('/api/tasks', {
      method: 'POST',
      cookie: adminCookie,
      body: taskBody({ title: 'turno_sera', description: '100% pronto' }),
    });

    const byTitle = await list(volunteerCookie, 'q=filtro&sort=title&direction=asc');
    expect(byTitle.items.map((item) => item.title)).toEqual(['Alfa filtro', 'Zeta filtro']);
    const reversed = await list(volunteerCookie, 'q=filtro&sort=title&direction=desc');
    expect(reversed.items[0]?.title).toBe('Zeta filtro');
    const urgent = await list(volunteerCookie, 'q=filtro&priority=high');
    expect(urgent.items.map((item) => item.title)).toEqual(['Zeta filtro']);
    const mine = await list(volunteerCookie, `q=filtro&assigneeId=${volunteerId}`);
    expect(mine.items.map((item) => item.title)).toEqual(['Zeta filtro']);
    const windowFrom = new Date(due - HOUR).toISOString();
    const windowTo = new Date(due + HOUR).toISOString();
    const interval = await list(
      volunteerCookie,
      `q=filtro&dueFrom=${encodeURIComponent(windowFrom)}&dueTo=${encodeURIComponent(windowTo)}`,
    );
    expect(interval.items.map((item) => item.title)).toEqual(['Alfa filtro']);
    const group = await list(
      volunteerCookie,
      `groupId=${groupA}&status=todo&sort=createdAt&direction=desc`,
    );
    expect(group.total).toBeGreaterThan(0);
    const outside = await list(coordinatorCookie, `groupId=${groupB}`);
    expect(outside).toMatchObject({ items: [], total: 0 });
    const beyond = await list(volunteerCookie, 'q=filtro&page=9&pageSize=1');
    expect(beyond).toMatchObject({ items: [], page: 9, pageSize: 1, total: 2 });
    const literal = await list(adminCookie, 'q=' + encodeURIComponent('turno_sera'));
    expect(literal.total).toBe(1);
    const wildcard = await list(adminCookie, 'q=' + encodeURIComponent('turnoXsera'));
    expect(wildcard.total).toBe(0);
    const percent = await list(adminCookie, 'q=' + encodeURIComponent('%'));
    expect(percent.items.map((item) => item.title)).toEqual(['turno_sera']);

    expect((await call('/api/tasks?extra=1', { cookie: adminCookie })).status).toBe(400);
    expect((await call('/api/tasks?pageSize=51', { cookie: adminCookie })).status).toBe(400);
    expect((await call('/api/tasks?sort=drop', { cookie: adminCookie })).status).toBe(400);
    expect((await call(`/api/tasks/${mainTaskId}`, { cookie: outsiderCookie })).status).toBe(404);
  });

  it('blocca il passaggio da annullata a completata', async () => {
    const created = await call('/api/tasks', {
      method: 'POST',
      cookie: coordinatorCookie,
      body: taskBody({ title: 'Da annullare', assigneeIds: [volunteerId] }),
    });
    const id = idOf(await created.json());
    const cancelled = await call(`/api/tasks/${id}/cancel`, {
      method: 'POST',
      cookie: coordinatorCookie,
    });
    expect(cancelled.status).toBe(200);
    const completed = await call(`/api/tasks/${id}/complete`, {
      method: 'POST',
      cookie: adminCookie,
    });
    expect(completed.status).toBe(409);
    expect(errorMessage(await completed.json())).toBe(CONFLICT);
    expect(
      ((await (await call(`/api/tasks/${id}`, { cookie: adminCookie })).json()) as TaskBody).status,
    ).toBe('cancelled');
  });

  it('fa vincere una sola richiesta di completamento', async () => {
    const created = await call('/api/tasks', {
      method: 'POST',
      cookie: adminCookie,
      body: taskBody({ title: 'Corsa', assigneeIds: [volunteerId] }),
    });
    const id = idOf(await created.json());
    const [first, second] = await Promise.all([
      call(`/api/tasks/${id}/complete`, { method: 'POST', cookie: volunteerCookie }),
      call(`/api/tasks/${id}/complete`, { method: 'POST', cookie: volunteerCookie }),
    ]);
    expect([first.status, second.status].sort()).toEqual([200, 409]);
    const history = (await (
      await call(`/api/tasks/${id}/history`, { cookie: coordinatorCookie })
    ).json()) as { items: { action: string }[] };
    expect(history.items.filter((item) => item.action === 'task.completed')).toHaveLength(1);
  });

  it('rilascia e riapre solo chi è autorizzato', async () => {
    const created = await call('/api/tasks', {
      method: 'POST',
      cookie: adminCookie,
      body: taskBody({ title: 'Rilascio', assigneeIds: [volunteerId] }),
    });
    const id = idOf(await created.json());
    expect(
      (await call(`/api/tasks/${id}/claim`, { method: 'POST', cookie: volunteerCookie })).status,
    ).toBe(200);
    const released = await call(`/api/tasks/${id}/release`, {
      method: 'POST',
      cookie: volunteerCookie,
    });
    expect(await released.json()).toMatchObject({ status: 'todo', claimedBy: null });
    expect(
      (await call(`/api/tasks/${id}/complete`, { method: 'POST', cookie: volunteerCookie })).status,
    ).toBe(200);
    expect(
      (await call(`/api/tasks/${id}/reopen`, { method: 'POST', cookie: volunteerCookie })).status,
    ).toBe(403);
    const reopened = await call(`/api/tasks/${id}/reopen`, {
      method: 'POST',
      cookie: coordinatorCookie,
    });
    expect(reopened.status).toBe(200);
    expect(await reopened.json()).toMatchObject({
      status: 'in_progress',
      claimedBy: coordinatorId,
    });
  });
});

type TaskBody = { id: string; title: string; status: string; groupId: string };

function taskBody(overrides: Record<string, unknown>): Record<string, unknown> {
  return {
    title: 'Attività di prova',
    description: '',
    groupId: groupA,
    assigneeIds: [],
    priority: 'normal',
    dueAt: null,
    ...overrides,
  };
}

function patchBody(overrides: Record<string, unknown>): Record<string, unknown> {
  return {
    title: 'Attività di prova',
    description: '',
    assigneeIds: [],
    priority: 'normal',
    dueAt: null,
    ...overrides,
  };
}

function zeros(): Record<string, number> {
  return {
    assignedOpen: 0,
    claimable: 0,
    urgentOpen: 0,
    overdue: 0,
    dueSoon: 0,
    openChecklists: 0,
  };
}

async function dashboard(cookie: string): Promise<{
  personal: Record<string, number>;
  notifications: unknown[];
  group: {
    open: number;
    overdue: number;
    completedLast30Days: number;
    checklistsInProgress: number;
    assignments: { userId: string; fullName: string; openTasks: number }[];
  } | null;
}> {
  const response = await call('/api/dashboard', { cookie });
  expect(response.status).toBe(200);
  return (await response.json()) as Awaited<ReturnType<typeof dashboard>>;
}

async function list(
  cookie: string,
  query: string,
): Promise<{ items: { title: string }[]; page: number; pageSize: number; total: number }> {
  const response = await call(`/api/tasks?${query}`, { cookie });
  expect(response.status).toBe(200);
  return (await response.json()) as {
    items: { title: string }[];
    page: number;
    pageSize: number;
    total: number;
  };
}

async function person(
  fullName: string,
  email: string,
  role: string,
  groupIds: string[],
): Promise<{ id: string; cookie: string }> {
  const response = await call('/api/users', {
    method: 'POST',
    cookie: adminCookie,
    body: { fullName, email, role, groupIds },
  });
  expect(response.status).toBe(201);
  const body = (await response.json()) as { user: { id: string }; inviteUrl: string };
  const accepted = await call('/api/auth/invitations/accept', {
    method: 'POST',
    body: { token: decodeURIComponent(new URL(body.inviteUrl).hash.slice(1)), password: PASSWORD },
  });
  expect(accepted.status).toBe(200);
  return { id: body.user.id, cookie: cookieOf(accepted) };
}

async function count(table: 'tasks'): Promise<number> {
  const row = await env.DB.prepare(`SELECT COUNT(*) AS n FROM ${table}`).first<{ n: number }>();
  return Number(row?.n ?? 0);
}

async function call(
  path: string,
  options?: { method?: string; body?: unknown; cookie?: string },
): Promise<Response> {
  const method = options?.method ?? 'GET';
  const headers = new Headers();
  const writes = method !== 'GET' && method !== 'HEAD';
  if (writes) {
    headers.set('Content-Type', 'application/json');
    headers.set('X-Volontari-Request', '1');
    headers.set('Origin', ORIGIN);
  }
  if (options?.cookie) {
    headers.set('Cookie', `volontari_session=${options.cookie}`);
  }
  return exports.default.fetch(
    new Request(`${ORIGIN}${path}`, {
      method,
      headers,
      body: writes ? JSON.stringify(options?.body ?? {}) : null,
    }),
  );
}

function cookieOf(response: Response): string {
  const values =
    typeof response.headers.getSetCookie === 'function' ? response.headers.getSetCookie() : [];
  const header =
    values.find((value) => value.includes('volontari_session=')) ??
    response.headers.get('set-cookie') ??
    '';
  const match = /volontari_session=([^;]*)/.exec(header);
  if (!match?.[1]) {
    throw new Error('cookie mancante');
  }
  return match[1];
}

function idOf(body: unknown): string {
  if (
    typeof body === 'object' &&
    body !== null &&
    'id' in body &&
    typeof (body as { id?: unknown }).id === 'string'
  ) {
    return (body as { id: string }).id;
  }
  throw new Error('id mancante');
}

async function jsonOf(response: Response): Promise<unknown> {
  expect(response.status).toBeGreaterThanOrEqual(200);
  expect(response.status).toBeLessThan(300);
  return response.json();
}

function errorMessage(body: unknown): string | undefined {
  if (typeof body !== 'object' || body === null || !('error' in body)) {
    return undefined;
  }
  const error = (body as { error?: unknown }).error;
  if (typeof error !== 'object' || error === null) {
    return undefined;
  }
  const message = (error as { message?: unknown }).message;
  return typeof message === 'string' ? message : undefined;
}
