import { describe, expect, it } from 'vitest';
import { exports } from 'cloudflare:workers';

const ORIGIN = 'http://volontari.test';
const PASSWORD = 'frase-di-prova-lunga';
const BLOCKED = "Prima di concludere l'attività completa la checklist collegata: Controllo FOO.";

let adminCookie = '';
let coordinatorCookie = '';
let volunteerCookie = '';
let otherCookie = '';
let groupA = '';
let volunteerId = '';
let templateId = '';
let taskId = '';

describe('checklist collegate alle attività', () => {
  it('prepara le persone e il modello', async () => {
    const setup = await call('/api/setup', {
      method: 'POST',
      body: {
        bootstrapToken: 'token-di-collaudo-fase-2',
        fullName: 'Ada Admin',
        email: 'admin@example.org',
        password: PASSWORD,
      },
    });
    adminCookie = cookieOf(setup);
    groupA = idOf(
      await jsonOf(
        await call('/api/groups', {
          method: 'POST',
          cookie: adminCookie,
          body: { name: 'Squadra Alfa', description: '' },
        }),
      ),
    );
    const coordinator = await person('Ciro Coord', 'ciro@example.org', 'coordinator', [groupA]);
    const volunteer = await person('Vera Volontaria', 'vera@example.org', 'volunteer', [groupA]);
    const other = await person('Nino Esterno', 'nino@example.org', 'volunteer', [groupA]);
    coordinatorCookie = coordinator.cookie;
    volunteerCookie = volunteer.cookie;
    otherCookie = other.cookie;
    volunteerId = volunteer.id;

    const refused = await call('/api/checklist-templates', {
      method: 'POST',
      cookie: volunteerCookie,
      body: createTemplateBody(),
    });
    expect(refused.status).toBe(403);

    const created = await call('/api/checklist-templates', {
      method: 'POST',
      cookie: coordinatorCookie,
      body: createTemplateBody(),
    });
    expect(created.status).toBe(201);
    const template = (await created.json()) as TemplateBody;
    templateId = template.id;
    expect(template.items.map((item) => item.label)).toEqual(['Estintore', 'Registro']);
  });

  it('riordina le voci e ne conserva una copia nelle esecuzioni', async () => {
    const reordered = await call(`/api/checklist-templates/${templateId}`, {
      method: 'PATCH',
      cookie: coordinatorCookie,
      body: {
        title: 'Controllo FOO',
        description: 'Controlli del turno',
        status: 'active',
        items: [
          { label: 'Registro', helpText: 'Firma', required: false },
          { label: 'Estintore', helpText: 'Pressione', required: true },
        ],
      },
    });
    expect(reordered.status).toBe(200);
    const template = (await reordered.json()) as TemplateBody;
    expect(template.items.map((item) => [item.label, item.required])).toEqual([
      ['Registro', false],
      ['Estintore', true],
    ]);

    const first = await startRun(volunteerCookie);
    const second = await startRun(coordinatorCookie);
    expect(first.items.map(copyOf)).toEqual(template.items.map(copyOf));
    expect(second.items.map(copyOf)).toEqual(template.items.map(copyOf));
    expect(
      (
        await call(`/api/checklist-runs/${first.id}/complete`, {
          method: 'POST',
          cookie: volunteerCookie,
        })
      ).status,
    ).toBe(409);

    const saved = await call(`/api/checklist-runs/${first.id}/items/${requiredItem(first).id}`, {
      method: 'PATCH',
      cookie: volunteerCookie,
      body: { result: 'compliant', note: 'Ok' },
    });
    expect(saved.status).toBe(200);
    const reread = (await (
      await call(`/api/checklist-runs/${first.id}`, { cookie: volunteerCookie })
    ).json()) as RunBody;
    expect(requiredItem(reread).result).toBe('compliant');
    expect(requiredItem(reread).note).toBe('Ok');
    const optional = first.items.find((item) => item.label === 'Registro');
    expect(optional).toBeTruthy();
    expect(
      (
        await call(`/api/checklist-runs/${first.id}/items/${requiredItem(first).id}`, {
          method: 'PATCH',
          cookie: volunteerCookie,
          body: { result: 'not_applicable', note: '' },
        })
      ).status,
    ).toBe(400);

    await setResult(first, volunteerCookie, 'Estintore', 'non_compliant');
    await setResult(first, volunteerCookie, 'Registro', 'not_applicable');
    const closed = await call(`/api/checklist-runs/${first.id}/complete`, {
      method: 'POST',
      cookie: volunteerCookie,
    });
    expect(closed.status).toBe(200);
    expect(await closed.json()).toMatchObject({ status: 'completed', outcome: 'non_compliant' });

    await setResult(second, coordinatorCookie, 'Estintore', 'compliant');
    await setResult(second, coordinatorCookie, 'Registro', 'not_applicable');
    const compliant = await call(`/api/checklist-runs/${second.id}/complete`, {
      method: 'POST',
      cookie: coordinatorCookie,
    });
    expect(await compliant.json()).toMatchObject({ outcome: 'compliant' });

    const snapshot = [await runItems(first.id), await runItems(second.id)];
    expect(
      (
        await call(`/api/checklist-templates/${templateId}`, {
          method: 'PATCH',
          cookie: adminCookie,
          body: {
            title: 'Controllo cambiato',
            description: 'Testo nuovo',
            status: 'active',
            items: [{ label: 'Voce nuova', helpText: '', required: true }],
          },
        })
      ).status,
    ).toBe(200);
    expect([await runItems(first.id), await runItems(second.id)]).toEqual(snapshot);
    expect(
      (await (
        await call(`/api/checklist-runs/${first.id}`, { cookie: adminCookie })
      ).json()) as RunBody,
    ).toMatchObject({
      title: 'Controllo FOO',
    });
  });

  it('nasconde l’esecuzione di un altro volontario e la mostra al coordinatore', async () => {
    const hidden = await call(`/api/checklist-runs/${(await runStartedBy(volunteerCookie)).id}`, {
      cookie: otherCookie,
    });
    expect(hidden.status).toBe(404);
    const visible = await call(`/api/checklist-runs/${(await runStartedBy(volunteerCookie)).id}`, {
      cookie: coordinatorCookie,
    });
    expect(visible.status).toBe(200);
  });

  it('blocca la conclusione dell’attività finché la checklist collegata non è chiusa', async () => {
    const restored = await call(`/api/checklist-templates/${templateId}`, {
      method: 'PATCH',
      cookie: coordinatorCookie,
      body: {
        title: 'Controllo FOO',
        description: 'Controlli del turno',
        status: 'active',
        items: [
          { label: 'Estintore', helpText: 'Pressione', required: true },
          { label: 'Registro', helpText: 'Firma', required: false },
        ],
      },
    });
    expect(restored.status).toBe(200);
    const task = await call('/api/tasks', {
      method: 'POST',
      cookie: coordinatorCookie,
      body: {
        title: 'Attività A',
        description: '',
        groupId: groupA,
        assigneeIds: [volunteerId],
        checklistTemplateIds: [templateId],
        priority: 'normal',
        dueAt: null,
      },
    });
    expect(task.status).toBe(201);
    const created = (await task.json()) as {
      id: string;
      checklists: { title: string; run: unknown }[];
    };
    taskId = created.id;
    expect(created.checklists).toEqual([
      expect.objectContaining({ templateId, title: 'Controllo FOO', run: null }),
    ]);
    const seen = await call(`/api/tasks/${taskId}`, { cookie: volunteerCookie });
    expect(await seen.json()).toMatchObject({
      checklists: [expect.objectContaining({ title: 'Controllo FOO', run: null })],
    });

    const early = await call(`/api/tasks/${taskId}/complete`, {
      method: 'POST',
      cookie: volunteerCookie,
    });
    expect(early.status).toBe(409);
    expect(errorMessage(await early.json())).toBe(BLOCKED);

    const started = await call(`/api/checklist-templates/${templateId}/runs`, {
      method: 'POST',
      cookie: volunteerCookie,
      body: { taskId },
    });
    expect(started.status).toBe(201);
    const run = (await started.json()) as RunBody;
    expect(run.taskId).toBe(taskId);
    expect(
      (await call(`/api/tasks/${taskId}/complete`, { method: 'POST', cookie: volunteerCookie }))
        .status,
    ).toBe(409);
    await setResult(run, volunteerCookie, 'Estintore', 'compliant');
    await setResult(run, volunteerCookie, 'Registro', 'compliant');
    expect(
      (
        await call(`/api/checklist-runs/${run.id}/complete`, {
          method: 'POST',
          cookie: volunteerCookie,
        })
      ).status,
    ).toBe(200);
    const done = await call(`/api/tasks/${taskId}/complete`, {
      method: 'POST',
      cookie: volunteerCookie,
    });
    expect(done.status).toBe(200);
    expect(await done.json()).toMatchObject({ status: 'completed' });

    const linkedByCoordinator = await call('/api/tasks', {
      method: 'POST',
      cookie: coordinatorCookie,
      body: {
        title: 'Attività B',
        description: '',
        groupId: groupA,
        assigneeIds: [volunteerId],
        checklistTemplateIds: [templateId],
        priority: 'normal',
        dueAt: null,
      },
    });
    const secondTask = idOf(await linkedByCoordinator.json());
    const coordinatorRun = await call(`/api/checklist-templates/${templateId}/runs`, {
      method: 'POST',
      cookie: coordinatorCookie,
      body: { taskId: secondTask },
    });
    const runId = idOf(await coordinatorRun.json());
    expect((await call(`/api/checklist-runs/${runId}`, { cookie: volunteerCookie })).status).toBe(
      200,
    );
    expect((await call(`/api/checklist-runs/${runId}`, { cookie: otherCookie })).status).toBe(404);
  });
});

type TemplateBody = {
  id: string;
  items: { label: string; required: boolean; helpText: string | null }[];
};
type RunBody = {
  id: string;
  taskId: string | null;
  title: string;
  items: {
    id: string;
    label: string;
    helpText: string | null;
    required: boolean;
    result: string;
    note: string | null;
  }[];
};

function createTemplateBody(): Record<string, unknown> {
  return {
    title: 'Controllo FOO',
    description: 'Controlli del turno',
    groupId: groupA,
    items: [
      { label: 'Estintore', helpText: 'Pressione', required: true },
      { label: 'Registro', helpText: 'Firma', required: false },
    ],
  };
}

function copyOf(item: { label: string; helpText: string | null; required: boolean }): {
  label: string;
  helpText: string | null;
  required: boolean;
} {
  return { label: item.label, helpText: item.helpText, required: item.required };
}

function requiredItem(run: RunBody): RunBody['items'][number] {
  const item = run.items.find((entry) => entry.label === 'Estintore');
  if (!item) {
    throw new Error('voce mancante');
  }
  return item;
}

async function startRun(cookie: string): Promise<RunBody> {
  const response = await call(`/api/checklist-templates/${templateId}/runs`, {
    method: 'POST',
    cookie,
    body: {},
  });
  expect(response.status).toBe(201);
  return (await response.json()) as RunBody;
}

async function setResult(
  run: RunBody,
  cookie: string,
  label: string,
  result: string,
): Promise<void> {
  const current = await runItems(run.id);
  const item = current.find((entry) => entry.label === label);
  if (!item) {
    throw new Error(label);
  }
  const response = await call(`/api/checklist-runs/${run.id}/items/${item.id}`, {
    method: 'PATCH',
    cookie,
    body: { result, note: '' },
  });
  expect(response.status).toBe(200);
}

async function runItems(runId: string): Promise<RunBody['items']> {
  const response = await call(`/api/checklist-runs/${runId}`, { cookie: adminCookie });
  expect(response.status).toBe(200);
  return ((await response.json()) as RunBody).items;
}

async function runStartedBy(cookie: string): Promise<{ id: string }> {
  const response = await call('/api/checklist-runs', { cookie });
  const body = (await response.json()) as { items: { id: string }[] };
  const first = body.items[0];
  if (!first) {
    throw new Error('esecuzione mancante');
  }
  return first;
}

async function person(
  fullName: string,
  email: string,
  role: string,
  groupIds: string[],
): Promise<{ id: string; cookie: string }> {
  const response = await call('/api/users', {
    method: 'POST',
    cookie: adminCookie,
    body: { fullName, email, role, groupIds },
  });
  expect(response.status).toBe(201);
  const body = (await response.json()) as { user: { id: string }; inviteUrl: string };
  const accepted = await call('/api/auth/invitations/accept', {
    method: 'POST',
    body: { token: decodeURIComponent(new URL(body.inviteUrl).hash.slice(1)), password: PASSWORD },
  });
  return { id: body.user.id, cookie: cookieOf(accepted) };
}

async function call(
  path: string,
  options?: { method?: string; body?: unknown; cookie?: string },
): Promise<Response> {
  const method = options?.method ?? 'GET';
  const headers = new Headers();
  const writes = method !== 'GET' && method !== 'HEAD';
  if (writes) {
    headers.set('Content-Type', 'application/json');
    headers.set('X-Volontari-Request', '1');
    headers.set('Origin', ORIGIN);
  }
  if (options?.cookie) {
    headers.set('Cookie', `volontari_session=${options.cookie}`);
  }
  return exports.default.fetch(
    new Request(`${ORIGIN}${path}`, {
      method,
      headers,
      body: writes ? JSON.stringify(options?.body ?? {}) : null,
    }),
  );
}

function cookieOf(response: Response): string {
  const values =
    typeof response.headers.getSetCookie === 'function' ? response.headers.getSetCookie() : [];
  const header = values.find((value) => value.includes('volontari_session=')) ?? '';
  const match = /volontari_session=([^;]*)/.exec(header);
  if (!match?.[1]) {
    throw new Error('cookie mancante');
  }
  return match[1];
}

function idOf(body: unknown): string {
  if (
    typeof body === 'object' &&
    body !== null &&
    'id' in body &&
    typeof (body as { id?: unknown }).id === 'string'
  ) {
    return (body as { id: string }).id;
  }
  throw new Error('id mancante');
}

async function jsonOf(response: Response): Promise<unknown> {
  expect(response.status).toBeGreaterThanOrEqual(200);
  expect(response.status).toBeLessThan(300);
  return response.json();
}

function errorMessage(body: unknown): string | undefined {
  if (typeof body !== 'object' || body === null || !('error' in body)) {
    return undefined;
  }
  const error = (body as { error?: unknown }).error;
  if (typeof error !== 'object' || error === null) {
    return undefined;
  }
  const message = (error as { message?: unknown }).message;
  return typeof message === 'string' ? message : undefined;
}
