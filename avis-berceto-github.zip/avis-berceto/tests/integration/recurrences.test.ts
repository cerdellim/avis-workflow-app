import { env, exports } from 'cloudflare:workers';
import { describe, expect, it } from 'vitest';
import { dueAtMillis, romeToday } from '../../src/worker/recurrence-dates';
import { generateOccurrences } from '../../src/worker/recurrences';

const ORIGIN = 'http://volontari.test';
const BOOTSTRAP = 'token-di-collaudo-fase-2';
const PASSWORD = 'frase-di-prova-lunga';

let adminCookie = '';
let coordinatorCookie = '';
let volunteerCookie = '';
let outsiderCookie = '';
let groupId = '';
let otherGroupId = '';
let volunteerId = '';

describe('ricorrenze e calendario', () => {
  it('prepara le persone', async () => {
    const setup = await call('/api/setup', {
      method: 'POST',
      body: {
        bootstrapToken: BOOTSTRAP,
        fullName: 'Ada Admin',
        email: 'admin-ricorrenze@example.org',
        password: PASSWORD,
      },
    });
    adminCookie = cookieOf(setup);
    groupId = idOf(
      await jsonOf(
        await call('/api/groups', {
          method: 'POST',
          cookie: adminCookie,
          body: { name: 'Squadra Ricorrente', description: '' },
        }),
      ),
    );
    otherGroupId = idOf(
      await jsonOf(
        await call('/api/groups', {
          method: 'POST',
          cookie: adminCookie,
          body: { name: 'Squadra Esterna', description: '' },
        }),
      ),
    );
    const coordinator = await person('Ciro Coord', 'ciro-ricorrenze@example.org', 'coordinator', [
      groupId,
    ]);
    const volunteer = await person('Vera Volontaria', 'vera-ricorrenze@example.org', 'volunteer', [
      groupId,
    ]);
    const outsider = await person('Nino Esterno', 'nino-ricorrenze@example.org', 'volunteer', [
      otherGroupId,
    ]);
    coordinatorCookie = coordinator.cookie;
    volunteerCookie = volunteer.cookie;
    outsiderCookie = outsider.cookie;
    volunteerId = volunteer.id;
  });

  it('nega la regola a un volontario e a un gruppo fuori perimetro', async () => {
    expect((await call('/api/recurrences', { cookie: volunteerCookie })).status).toBe(403);
    const created = await call('/api/recurrences', {
      method: 'POST',
      cookie: volunteerCookie,
      body: dailyBody({ title: 'Vietata' }),
    });
    expect(created.status).toBe(403);
    const outside = await call('/api/recurrences', {
      method: 'POST',
      cookie: coordinatorCookie,
      body: dailyBody({ title: 'Altro gruppo', groupId: otherGroupId }),
    });
    expect(outside.status).toBe(404);
  });

  it('crea 60 occorrenze giornaliere e non le duplica', async () => {
    const created = await jsonOf(
      await call('/api/recurrences', {
        method: 'POST',
        cookie: coordinatorCookie,
        body: dailyBody({
          title: 'Turno giornaliero',
          assigneeIds: [volunteerId],
          startsOn: '2026-12-01',
          endsOn: '2027-01-29',
        }),
      }),
    );
    const ruleId = idOf(created);
    expect(await generateOccurrences(env.DB, at('2026-12-01'))).toBe(60);
    const rows = await occurrences(ruleId);
    expect(rows).toHaveLength(60);
    expect(rows[0]).toMatchObject({
      occurrence_local_date: '2026-12-01',
      title: 'Turno giornaliero',
      user_id: volunteerId,
    });
    expect(rows.at(-1)?.occurrence_local_date).toBe('2027-01-29');
    expect(await generateOccurrences(env.DB, at('2026-12-01'))).toBe(0);
    expect(await occurrences(ruleId)).toHaveLength(60);
  });

  it('ripete il job in parallelo senza duplicare', async () => {
    const ruleId = idOf(
      await jsonOf(
        await call('/api/recurrences', {
          method: 'POST',
          cookie: adminCookie,
          body: dailyBody({
            title: 'Turno parallelo',
            startsOn: '2026-12-01',
            endsOn: '2026-12-10',
          }),
        }),
      ),
    );
    await Promise.all([
      generateOccurrences(env.DB, at('2026-12-01')),
      generateOccurrences(env.DB, at('2026-12-01')),
    ]);
    expect(await occurrences(ruleId)).toHaveLength(10);
  });

  it('completa il lotto successivo dopo il tetto di 80', async () => {
    const first = idOf(
      await jsonOf(
        await call('/api/recurrences', {
          method: 'POST',
          cookie: adminCookie,
          body: dailyBody({ title: 'Lotto A', startsOn: '2026-12-01', endsOn: '2027-01-31' }),
        }),
      ),
    );
    const second = idOf(
      await jsonOf(
        await call('/api/recurrences', {
          method: 'POST',
          cookie: adminCookie,
          body: dailyBody({ title: 'Lotto B', startsOn: '2026-12-01', endsOn: '2027-01-31' }),
        }),
      ),
    );
    expect(await generateOccurrences(env.DB, at('2026-12-01'))).toBe(80);
    expect((await occurrences(first)).length + (await occurrences(second)).length).toBe(80);
    expect(await generateOccurrences(env.DB, at('2026-12-01'))).toBe(44);
    expect(await occurrences(first)).toHaveLength(62);
    expect(await occurrences(second)).toHaveLength(62);
  });

  it('genera solo lunedì e giovedì', async () => {
    const ruleId = idOf(
      await jsonOf(
        await call('/api/recurrences', {
          method: 'POST',
          cookie: coordinatorCookie,
          body: {
            ...baseBody(),
            title: 'Lunedì e giovedì',
            frequency: 'weekly',
            weekdays: [1, 4],
            startsOn: '2026-12-01',
            endsOn: '2026-12-31',
          },
        }),
      ),
    );
    await generateOccurrences(env.DB, at('2026-12-01'));
    const dates = (await occurrences(ruleId)).map((row) => row.occurrence_local_date);
    expect(dates.every((date) => date !== undefined)).toBe(true);
    for (const date of dates) {
      const day = Temporal.PlainDate.from(date ?? '').dayOfWeek;
      expect(day === 1 || day === 4).toBe(true);
    }
    expect(dates).toContain('2026-12-03');
    expect(dates).not.toContain('2026-12-01');
  });

  it('accorcia il 31 e il 29 febbraio avanzando l’orologio', async () => {
    const monthly = idOf(
      await jsonOf(
        await call('/api/recurrences', {
          method: 'POST',
          cookie: adminCookie,
          body: {
            ...baseBody(),
            title: 'Fine mese',
            frequency: 'monthly',
            dayOfMonth: 31,
            startsOn: '2027-01-01',
          },
        }),
      ),
    );
    await generateOccurrences(env.DB, at('2027-01-01'));
    expect((await occurrences(monthly)).map((row) => row.occurrence_local_date)).toEqual([
      '2027-01-31',
      '2027-02-28',
    ]);
    await generateOccurrences(env.DB, at('2027-02-01'));
    expect((await occurrences(monthly)).map((row) => row.occurrence_local_date)).toEqual([
      '2027-01-31',
      '2027-02-28',
      '2027-03-31',
    ]);

    const yearly = idOf(
      await jsonOf(
        await call('/api/recurrences', {
          method: 'POST',
          cookie: adminCookie,
          body: {
            ...baseBody(),
            title: 'Anno bisestile',
            frequency: 'yearly',
            monthOfYear: 2,
            dayOfMonth: 29,
            startsOn: '2027-01-01',
          },
        }),
      ),
    );
    await generateOccurrences(env.DB, at('2027-01-15'));
    await generateOccurrences(env.DB, at('2028-01-15'));
    expect((await occurrences(yearly)).map((row) => row.occurrence_local_date)).toEqual([
      '2027-02-28',
      '2028-02-29',
    ]);
  });

  it('salva l’ora legale e l’ora solare', async () => {
    const spring = idOf(
      await jsonOf(
        await call('/api/recurrences', {
          method: 'POST',
          cookie: adminCookie,
          body: dailyBody({
            title: 'Cambio di marzo',
            localTime: '02:30',
            startsOn: '2026-03-29',
            endsOn: '2026-03-29',
          }),
        }),
      ),
    );
    const autumn = idOf(
      await jsonOf(
        await call('/api/recurrences', {
          method: 'POST',
          cookie: adminCookie,
          body: dailyBody({
            title: 'Cambio di ottobre',
            localTime: '02:30',
            startsOn: '2026-10-25',
            endsOn: '2026-10-25',
          }),
        }),
      ),
    );
    await generateOccurrences(env.DB, at('2026-03-29'));
    await generateOccurrences(env.DB, at('2026-10-25'));
    expect((await occurrences(spring))[0]?.due_at).toBe(Date.parse('2026-03-29T01:30:00.000Z'));
    expect((await occurrences(autumn))[0]?.due_at).toBe(Date.parse('2026-10-25T00:30:00.000Z'));
  });

  it('non genera date nuove da una regola sospesa e può annullare le future', async () => {
    const ruleId = idOf(
      await jsonOf(
        await call('/api/recurrences', {
          method: 'POST',
          cookie: adminCookie,
          body: dailyBody({ title: 'Sospesa', startsOn: '2026-12-01', endsOn: '2026-12-05' }),
        }),
      ),
    );
    await generateOccurrences(env.DB, at('2026-12-01'));
    const suspended = await call(`/api/recurrences/${ruleId}/suspend`, {
      method: 'POST',
      cookie: coordinatorCookie,
      body: { cancelFutureOpen: true },
    });
    expect(suspended.status).toBe(200);
    const today = romeToday(Date.now());
    const rows = await occurrences(ruleId);
    expect(rows).toHaveLength(5);
    expect(rows.map((row) => [row.occurrence_local_date, row.status])).toEqual(
      ['2026-12-01', '2026-12-02', '2026-12-03', '2026-12-04', '2026-12-05'].map((date) => [
        date,
        date > today ? 'cancelled' : 'todo',
      ]),
    );
    await generateOccurrences(env.DB, at('2026-12-03'));
    expect(await occurrences(ruleId)).toHaveLength(5);
  });

  it('lascia invariate le altre date e la regola quando si modifica un’occorrenza', async () => {
    const ruleId = idOf(
      await jsonOf(
        await call('/api/recurrences', {
          method: 'POST',
          cookie: coordinatorCookie,
          body: dailyBody({ title: 'Serie stabile', startsOn: '2026-12-01', endsOn: '2026-12-03' }),
        }),
      ),
    );
    await generateOccurrences(env.DB, at('2026-12-01'));
    const rows = await occurrences(ruleId);
    const target = rows[1];
    expect(target?.id).toBeTruthy();
    const edited = await call(`/api/tasks/${target?.id ?? ''}`, {
      method: 'PATCH',
      cookie: coordinatorCookie,
      body: {
        title: 'Solo questa',
        description: '',
        assigneeIds: [],
        priority: 'normal',
        dueAt: new Date(target?.due_at ?? 0).toISOString(),
      },
    });
    expect(edited.status).toBe(200);
    expect(await edited.json()).toMatchObject({
      title: 'Solo questa',
      recurrence: { detached: true, occurrenceLocalDate: '2026-12-02' },
    });
    const after = await occurrences(ruleId);
    expect(after.map((row) => row.title)).toEqual([
      'Serie stabile',
      'Solo questa',
      'Serie stabile',
    ]);
    const rule = await jsonOf(
      await call(`/api/recurrences/${ruleId}`, { cookie: coordinatorCookie }),
    );
    expect(rule).toMatchObject({ title: 'Serie stabile' });
  });

  it('non riscrive il titolo delle attività già create', async () => {
    const ruleId = idOf(
      await jsonOf(
        await call('/api/recurrences', {
          method: 'POST',
          cookie: adminCookie,
          body: dailyBody({
            title: 'Titolo vecchio',
            startsOn: '2026-12-01',
            endsOn: '2027-02-02',
          }),
        }),
      ),
    );
    await generateOccurrences(env.DB, at('2026-12-01'));
    const before = (await occurrences(ruleId)).map((row) => row.title);
    const patch = dailyBody({
      title: 'Titolo nuovo',
      startsOn: '2026-12-01',
      endsOn: '2027-02-02',
    });
    delete patch.groupId;
    const patched = await call(`/api/recurrences/${ruleId}`, {
      method: 'PATCH',
      cookie: adminCookie,
      body: patch,
    });
    expect(patched.status).toBe(200);
    await generateOccurrences(env.DB, at('2027-02-01'));
    const rows = await occurrences(ruleId);
    expect(rows.slice(0, before.length).every((row) => row.title === 'Titolo vecchio')).toBe(true);
    expect(rows.at(-1)).toMatchObject({
      occurrence_local_date: '2027-02-02',
      title: 'Titolo nuovo',
    });
  });

  it('mostra il calendario nel perimetro e rifiuta un intervallo troppo lungo', async () => {
    const calendar = await jsonOf(
      await call('/api/calendar?from=2026-12-01&to=2026-12-31', { cookie: volunteerCookie }),
    );
    expect(calendar).toMatchObject({ from: '2026-12-01', to: '2026-12-31' });
    const items = (calendar as { items: { title: string }[] }).items;
    expect(items.some((item) => item.title === 'Turno giornaliero')).toBe(true);
    const hidden = await jsonOf(
      await call('/api/calendar?from=2026-12-01&to=2026-12-31', { cookie: outsiderCookie }),
    );
    expect((hidden as { items: unknown[] }).items).toEqual([]);
    const tooLong = await call('/api/calendar?from=2026-12-01&to=2027-03-01', {
      cookie: volunteerCookie,
    });
    expect(tooLong.status).toBe(400);
    const tick = await call('/api/admin/jobs/tick', { method: 'POST', cookie: adminCookie });
    expect(tick.status).toBe(200);
    expect(
      (await call('/api/admin/jobs/tick', { method: 'POST', cookie: coordinatorCookie })).status,
    ).toBe(403);
  });
});

function at(date: string): number {
  return dueAtMillis(date, '12:00');
}

function baseBody(): Record<string, unknown> {
  return {
    description: '',
    groupId,
    assigneeIds: [],
    priority: 'normal',
    intervalCount: 1,
    localTime: '09:00',
  };
}

function dailyBody(overrides: Record<string, unknown>): Record<string, unknown> {
  return {
    ...baseBody(),
    title: 'Giornaliera',
    frequency: 'daily',
    startsOn: '2026-12-01',
    ...overrides,
  };
}

async function occurrences(ruleId: string): Promise<
  {
    id: string;
    title: string;
    occurrence_local_date: string;
    due_at: number;
    status: string;
    user_id: string | null;
  }[]
> {
  const rows = await env.DB.prepare(
    `SELECT t.id, t.title, t.occurrence_local_date, t.due_at, t.status, a.user_id
     FROM tasks t
     LEFT JOIN task_assignees a ON a.task_id = t.id
     WHERE t.recurrence_rule_id = ?
     ORDER BY t.occurrence_local_date`,
  )
    .bind(ruleId)
    .all<{
      id: string;
      title: string;
      occurrence_local_date: string;
      due_at: number;
      status: string;
      user_id: string | null;
    }>();
  return rows.results;
}

async function person(
  fullName: string,
  email: string,
  role: string,
  groupIds: string[],
): Promise<{ id: string; cookie: string }> {
  const response = await call('/api/users', {
    method: 'POST',
    cookie: adminCookie,
    body: { fullName, email, role, groupIds },
  });
  expect(response.status).toBe(201);
  const body = (await response.json()) as { user: { id: string }; inviteUrl: string };
  const accepted = await call('/api/auth/invitations/accept', {
    method: 'POST',
    body: { token: decodeURIComponent(new URL(body.inviteUrl).hash.slice(1)), password: PASSWORD },
  });
  expect(accepted.status).toBe(200);
  return { id: body.user.id, cookie: cookieOf(accepted) };
}

async function call(
  path: string,
  options?: { method?: string; body?: unknown; cookie?: string },
): Promise<Response> {
  const method = options?.method ?? 'GET';
  const headers = new Headers();
  const writes = method !== 'GET' && method !== 'HEAD';
  if (writes) {
    headers.set('Content-Type', 'application/json');
    headers.set('X-Volontari-Request', '1');
    headers.set('Origin', ORIGIN);
  }
  if (options?.cookie) {
    headers.set('Cookie', `volontari_session=${options.cookie}`);
  }
  return exports.default.fetch(
    new Request(`${ORIGIN}${path}`, {
      method,
      headers,
      body: writes ? JSON.stringify(options?.body ?? {}) : null,
    }),
  );
}

function cookieOf(response: Response): string {
  const values =
    typeof response.headers.getSetCookie === 'function' ? response.headers.getSetCookie() : [];
  const header =
    values.find((value) => value.includes('volontari_session=')) ??
    response.headers.get('set-cookie') ??
    '';
  const match = /volontari_session=([^;]*)/.exec(header);
  if (!match?.[1]) {
    throw new Error('cookie mancante');
  }
  return match[1];
}

function idOf(body: unknown): string {
  if (
    typeof body === 'object' &&
    body !== null &&
    'id' in body &&
    typeof (body as { id?: unknown }).id === 'string'
  ) {
    return (body as { id: string }).id;
  }
  throw new Error('id mancante');
}

async function jsonOf(response: Response): Promise<unknown> {
  expect(response.status).toBeGreaterThanOrEqual(200);
  expect(response.status).toBeLessThan(300);
  return response.json();
}
