# Piano di test

In Fase 0 non esiste codice eseguibile. Questo documento fissa che cosa dovrà essere provato, con quali strumenti e quali risultati non potranno essere dichiarati senza una prova reale.

## Strumenti

| Livello      | Strumento                                              | Dove gira                                                    |
| ------------ | ------------------------------------------------------ | ------------------------------------------------------------ |
| Statico      | `tsc --noEmit`, ESLint, Prettier                       | Tooling Node.js 22                                           |
| Unitario     | Vitest                                                 | Funzioni pure: ricorrenze, stati, permessi, confronto hash   |
| Integrazione | Vitest con `@cloudflare/vitest-pool-workers`           | Worker e D1 locale in Miniflare, lo stesso runtime delle API |
| End-to-end   | Playwright                                             | Applicazione locale, viewport telefono e desktop             |
| Schema       | Applicazione della migrazione su SQLite e su D1 locale | Fase 1                                                       |

I test di integrazione non usano un database remoto. Il deploy si prova solo nella Fase 9, dopo autorizzazione.

I test di login usano la stessa funzione di produzione: PBKDF2-SHA-256 a 10.000 iterazioni. Un test legge la costante e fallisce se non è 10.000. Un altro rifiuta una password di 15 caratteri e accetta una frase di 16.

## Comandi della Fase 1

```bash
npm run typecheck
npm run lint
npm test
npm run build
npm run db:migrate
npm run dev
```

`GET /api/health` sul server di sviluppo deve rispondere `200` con `database: "ok"` dopo la migrazione.

## Fase 1 — Ambiente

- `npm run build` del frontend.
- `npm run typecheck`.
- `npm run lint`.
- Avvio locale con il plugin Vite di Cloudflare.
- `wrangler d1 migrations apply volontari --local`.
- `GET /api/health` risponde `200` con il database raggiungibile e `503` se la query di controllo fallisce.
- Inserimento di una riga con chiave esterna inesistente: deve fallire.
- Una seconda applicazione della stessa migrazione non duplica lo schema.
- Pagina base renderizzata a 390×844 e a 1280×800.

## Fase 2 — Accesso e utenti

Automatici:

- Login con password corretta e cookie `HttpOnly`.
- Login errato con lo stesso messaggio del login di un utente inesistente.
- Sesto tentativo entro la finestra: `429`.
- Sessione oltre l'inattività e oltre la scadenza assoluta.
- Logout: il cookie precedente riceve `401`.
- Token di invito scaduto, già usato e di un utente disattivato.
- Token nel frammento: la richiesta di attivazione non lo scrive nell'URL del server.
- Volontario che invia un cambio di ruolo: rifiutato.
- Coordinatore che apre un gruppo di cui non è membro: `404`.
- Coordinatore che modifica una task del proprio gruppo: coperto dai test della Fase 3, insieme al rifiuto della stessa modifica fatta da un volontario.
- Richiesta mutante senza intestazione `X-Volontari-Request` o con `Origin` estraneo: rifiutata.
- Setup del primo amministratore rifiutato se un utente esiste già, anche con il token giusto.
- Confronto del token di bootstrap in tempo costante, coperto da test sul componente di confronto.

Manuale, con tre utenti:

1. Entrare come amministratore, creare un gruppo, creare un coordinatore e un volontario, copiare i due link.
2. Aprire i link in una sessione senza cookie, impostare le password.
3. Verificare che il coordinatore veda solo il proprio gruppo e che il volontario non veda l'amministrazione.

## Fase 3 — Attività e dashboard

Flusso obbligatorio, automatico e poi ripetuto nell'interfaccia:

1. L'amministratore crea una task nel gruppo.
2. Il coordinatore assegna il volontario.
3. Il volontario la prende in carico.
4. Il volontario la completa.
5. La dashboard dei tre ruoli, riletta dal database, mostra i conteggi nuovi.
6. Un refresh della lista restituisce la task completata.

Altri casi:

- Modifica autorizzata e modifica di un volontario sullo stesso campo.
- Assegnazione di due persone, di cui una fuori dal gruppo: la seconda viene rifiutata e nessuna scrittura parziale resta.
- Transizioni vietate, per esempio da `cancelled` a `completed`.
- Completamento concorrente: una sola delle due richieste vince.
- Filtri per stato, gruppo, assegnatario, priorità e intervallo di scadenza; ordinamenti ammessi; pagina oltre i dati.
- Task con `due_at` nel passato e stato aperto: conteggiata come scaduta. Task senza scadenza: esclusa.
- Task di un altro gruppo: `404` anche conoscendo l'id.
- Audit presente per creazione, presa in carico e completamento.

## Fase 4 — Checklist

- Creazione di un modello con voci obbligatorie e facoltative, riordino incluso.
- Avvio: le voci di esecuzione sono una copia, con gli stessi testi.
- Salvataggio di una voce e rilettura dopo una nuova richiesta.
- Chiusura bloccata se un obbligatorio è `pending` o `not_applicable`.
- Chiusura consentita con un obbligatorio `non_compliant`: esito `non_compliant`.
- Chiusura con tutti gli obbligatori `compliant` e un facoltativo `not_applicable`: esito `compliant`.
- Modifica del modello dopo due esecuzioni completate. Le due esecuzioni, voci incluse, restano byte per byte uguali sui campi copiati.
- Un volontario non legge l'esecuzione iniziata da un altro volontario. Il coordinatore del gruppo la legge.
- Un'attività con una checklist collegata non si conclude finché quell'esecuzione, avviata sull'attività, non è chiusa. L'assegnatario vede la checklist e può aprire l'esecuzione avviata dal coordinatore.

## Fase 5 — Ricorrenze

Orologio iniettato, fuso `Europe/Rome`.

| Caso                                    | Atteso                                                              |
| --------------------------------------- | ------------------------------------------------------------------- |
| Giornaliera, intervallo 1, 60 date      | 60 task, una per data locale                                        |
| Settimanale lunedì e giovedì            | Solo quei giorni                                                    |
| Mensile, ancora il 31                   | 31 gennaio, 28 febbraio 2027, 31 marzo 2027                         |
| Annuale, 29 febbraio                    | 29 febbraio 2028 e 28 febbraio 2027                                 |
| 29 marzo 2026, ora 02:30                | `due_at` alle 01:30 UTC                                             |
| 25 ottobre 2026, ora 02:30              | `due_at` alle 00:30 UTC                                             |
| Stesso job eseguito due volte           | Nessun duplicato, anche con inserimenti paralleli sul vincolo unico |
| Job interrotto a metà di un lotto da 80 | Il lotto successivo completa senza duplicare                        |
| Regola sospesa                          | Nessuna data nuova                                                  |
| Modifica di una occorrenza              | Le altre date e la regola restano invariate                         |
| Modifica del titolo della regola        | Le task già create tengono il titolo precedente                     |

Il gate dei 60 giorni si ottiene avanzando l'orologio e rieseguendo il job, non generando un anno intero in un colpo solo.

## Fase 6 — Notifiche

Automatici, senza un telefono reale:

- La notifica interna nasce per l'assegnatario e non per un estraneo.
- Un volontario che chiede la notifica di un altro riceve `404`.
- Lo stesso evento non crea due righe con la stessa chiave di deduplica.
- Un errore `503` lascia la consegna riprovabile; al quarto esito resta `abandoned`.
- Un `410` elimina la sottoscrizione.
- Il payload push contiene il percorso della task, non solo il titolo.
- Il service worker, in test di pagina, apre quel percorso al click.

Non eseguibili dall'agente, da chiudere con checklist manuale prima di dichiarare il gate:

- Android, Chrome, PWA installata, applicazione in background.
- iPhone con la PWA aggiunta alla schermata Home e aperta dall'icona. Una scheda Safari non basta.
- Permesso notifiche chiesto da un pulsante, mai all'apertura della pagina.
- Negazione del permesso: l'app continua e il centro notifiche interno funziona.

Se questi dispositivi non sono disponibili, il gate G6 resta aperto e non si scrive che le push sono verificate.

## Fase 7 — Amministrazione, qualità, sicurezza

- Playwright sui flussi di task e checklist, come amministratore, coordinatore e volontario.
- IDOR sulle risorse di un altro gruppo e sulle notifiche altrui.
- Payload extra, tipi errati, stringhe lunghe, date impossibili.
- CSRF: form cross-site senza l'intestazione richiesta.
- Rate limit di login.
- Ricerca nel repository di chiavi private, `.dev.vars` e token reali. Il test fallisce se li trova.
- Export CSV con una cella che inizia con `=`: il file la neutralizza.
- Export JSON, azzeramento del D1 locale, ripristino con la procedura documentata, confronto dei conteggi e di alcuni record.
- Accessibilità delle pagine principali: nome accessibile sui pulsanti, focus visibile, errori dei form associati ai campi, contrasto del tema.
- Viewport 390×844 e 1280×800 sulle stesse pagine.

## Fase 8 — Preparazione al deploy

`npm run release:check` esegue tipi, lint, test, build e `node scripts/phase8-checks.ts`. Quest'ultimo non usa `--remote`. Controlla Wrangler, l'assenza di segreti nella build, manifest e service worker, poi avvia la build in locale e verifica:

- `GET /api/health` con database raggiungibile.
- Un percorso dell'interfaccia restituisce la pagina.
- Un'API assente risponde 404 JSON.
- `/sw.js` e il manifest sono serviti, e il service worker non usa la cache.
- `GET /__scheduled` esegue il cron sul database locale di prova.

La Fase 9, solo dopo autorizzazione, verifica login, ruoli, task, checklist, una ricorrenza e le notifiche interne sull'URL HTTPS. Le push su dispositivo restano una checklist manuale anche dopo il deploy.

## Definition of done di un test

Un test è superato solo se il comando è stato eseguito in questa sessione di lavoro e il risultato è nel report della fase. Un test descritto qui, o passato in una sessione precedente ma non rilanciato dopo una modifica correlata, non conta come verifica corrente.
